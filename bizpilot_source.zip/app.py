"""BizPilot v0.7.1 — question-triggered anomaly scan and opt-in data sources.

Business values come from a reproducible demo or an explicitly imported CSV.
Synthetic auxiliary tables are labeled; open-ended text-to-SQL is not implemented.
"""
from __future__ import annotations
import html
import json
import sqlite3
from pathlib import Path
import pandas as pd
import streamlit as st
from bizpilot.case_agent import investigate_case
from bizpilot.seller_ui import public_seller_workspace
from bizpilot.data import make_demo_data
from bizpilot.extra_sources import ensure_demo_sources,source_registry,analyze_extra_question
from bizpilot.question_analysis import detect_anomaly_intent
from bizpilot.overview import (prepare_frame,period_window,filter_frame,metrics,
                              metric_change,drivers,breakdown,anomaly_candidates,latest_daily_trend)
from bizpilot.deep_analysis import investigation, audit_agent
from bizpilot.question_analysis import analyze_question
from bizpilot.diagnostics import diagnose_all

st.set_page_config(page_title='BizPilot | 商业分析与决策工作台',page_icon='◈',layout='wide',initial_sidebar_state='expanded')
ROOT=Path(__file__).resolve().parent
DEMO_DB=ROOT/'data'/'demo.db'

@st.cache_resource(show_spinner=False)
def initialize_demo():
    if not DEMO_DB.exists():
        make_demo_data(DEMO_DB)
    ensure_demo_sources(DEMO_DB)
    return DEMO_DB

DB=DEMO_DB


@st.cache_data(show_spinner=False)
def load_data(db_path,db_mtime):
    with sqlite3.connect(f'file:{Path(db_path).resolve()}?mode=ro',uri=True) as con:
        frame=pd.read_sql_query('SELECT day, region, channel, category, revenue, orders, visits FROM daily_metrics',con)
    return prepare_frame(frame)

@st.cache_data(show_spinner=False)
def deep_dive(db_path,db_mtime):return investigation(db_path)

def e(x):return html.escape(str(x),quote=True)
def num(v,d=0):return f'{v:,.{d}f}' if v is not None else '—'
def money(v):return num(v)
def change(v):return f'{v:+.1f}%' if v is not None else '—'
LABEL={'visits':'流量','conversion':'转化率','aov':'客单价'}
NAV=['首页 / 自由提问','功能导航','经营概览','深度诊断','Agent 调查','证据审计','Olist 真实数据']
if st.session_state.get('page') not in NAV:st.session_state['page']='Olist 真实数据'
if 'question' not in st.session_state:st.session_state['question']='最近一周收入为什么下降？请调查主要损失来源和指标变化。'
if 'history' not in st.session_state:st.session_state['history']=[]
if 'scope' not in st.session_state:st.session_state['scope']={'period':'近7天','region':'全部','channel':'全部','category':'全部','compare':True}

def go(page):st.session_state['page']=page

def ask_question(q):
    st.session_state['question']=q
    st.session_state['agent_question_input']=q
    st.session_state.pop('dynamic_answer',None)
    st.session_state.pop('case_investigation',None)
    st.session_state['pending_query']=True
    st.session_state['page']='Agent 调查'
    if q.strip() and q not in st.session_state['history']:
        st.session_state['history']=[q]+st.session_state['history'][:8]

def header(kicker,title,subtitle):
    st.markdown(f'<div class="hero"><div class="eyebrow">{e(kicker)}</div><h1>{e(title)}</h1><p>{e(subtitle)}</p></div>',unsafe_allow_html=True)

def card(title,body,extra=''):
    st.markdown(f'<div class="bp-card"><div class="eyebrow">{e(extra)}</div><h3>{e(title)}</h3><p>{e(body)}</p></div>',unsafe_allow_html=True)

st.markdown("""<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
:root{--navy:#102b40;--teal:#0b8395;--line:#dce8f0;--sub:#667f93}
html,body,[data-testid="stApp"]{font-family:'DM Sans','PingFang SC',-apple-system,sans-serif}
[data-testid="stAppViewContainer"]{background:linear-gradient(160deg,#f5faff,#edf5fb 64%,#f7fbff)}
[data-testid="stHeader"]{background:transparent}
.block-container{max-width:1500px;padding-top:1rem;padding-bottom:3rem}
section[data-testid="stSidebar"]{background:linear-gradient(168deg,#0e2a40,#143552 70%,#102a41);border-right:0}
section[data-testid="stSidebar"] *{color:#e9f6fb}
section[data-testid="stSidebar"] small{color:#b7d8e4!important}
section[data-testid="stSidebar"] textarea,section[data-testid="stSidebar"] input{background:#284b64!important;color:white!important;border:1px solid #507288!important}
[data-testid="stMetric"]{background:#fff;border:1px solid var(--line);border-radius:16px;min-height:118px;padding:17px 19px;box-shadow:0 9px 24px #1747600a}
[data-testid="stMetricValue"]{color:#122f42;font-size:29px;font-weight:800}
[data-testid="stMetricLabel"]{font-size:12px;font-weight:700;color:#647c8f}
.stButton>button{border-radius:12px;min-height:44px;font-weight:750;transition:all .16s ease;border:1px solid #c7dbe7;box-shadow:0 3px 12px #0e3d580a}
section[data-testid="stSidebar"] .stButton>button{background:#203f56!important;color:#eefaff!important;border-color:#466c82!important}
section[data-testid="stSidebar"] .stButton>button[kind="primary"]{background:linear-gradient(115deg,#0d718a,#1196a4)!important;border-color:transparent!important}
.stButton>button:hover{border-color:#0d879b;color:#0b7085;transform:translateY(-1px)}
.stButton>button[kind="primary"],.stFormSubmitButton>button[kind="primary"]{background:linear-gradient(115deg,#0d718a,#1196a4);color:#fff;border:0;box-shadow:0 5px 16px #0b8f9c2a}
[data-testid="stDataFrame"]{border-radius:12px;overflow:hidden}
[data-testid="stTabs"] [data-baseweb="tab-list"]{gap:10px;flex-wrap:wrap}
[data-testid="stTabs"] [data-baseweb="tab"]{background:white;border:1px solid #d9e5ec;border-radius:12px;padding:10px 18px!important;font-weight:750}
[data-testid="stTabs"] [data-baseweb="tab"][aria-selected="true"]{background:#116f89!important;color:white!important}
[data-testid="stTabs"] [data-baseweb="tab-highlight"],[data-testid="stTabs"] [data-baseweb="tab-border"]{display:none}
.logo{font-size:31px;font-weight:850;letter-spacing:-1.3px;color:#fff;margin-bottom:8px}.logo span{color:#62d8e5}
.topbar{display:flex;justify-content:space-between;align-items:center;margin:2px 0 18px}.topbar strong{font-size:21px;color:#163b50;letter-spacing:-.5px}.topbar span{font-size:11px;letter-spacing:1.4px;color:#557c90;font-weight:700}
.hero{position:relative;overflow:hidden;background:linear-gradient(112deg,#102e49 0%,#135775 62%,#087e92 100%);padding:36px 42px;border-radius:22px;margin:4px 0 22px;color:white;box-shadow:0 18px 38px #0d496223}
.hero:after{content:'';position:absolute;right:-75px;top:-70px;width:390px;height:390px;border-radius:47%;border:1px solid #8ae9f55c;box-shadow:0 0 0 45px #8ae9f509,0 0 0 90px #c3f8fe0b;transform:rotate(25deg)}
.hero .eyebrow{letter-spacing:2.7px;font-size:11px;font-weight:800;color:#99f1ff}
.hero h1{position:relative;z-index:1;font-size:35px;font-weight:850;letter-spacing:-1px;line-height:1.4;margin:11px 0 7px;color:white}
.hero p{position:relative;z-index:1;color:#def0f9;font-size:14px;line-height:1.8;max-width:960px}
.bp-card{border:1px solid #dbe8ef;border-radius:17px;background:#fff;padding:23px;margin:6px 0 15px;box-shadow:0 7px 23px #163c5009}
.bp-card h3{font-size:18px;color:#17394d;margin:3px 0 9px;font-weight:800}.bp-card p{font-size:13px;color:#627c8e;line-height:1.8;margin:0}
.eyebrow{color:#5e92a6;letter-spacing:1.8px;font-weight:850;font-size:10px;margin-bottom:9px}
.sectiontitle{margin:22px 0 13px;font-size:19px;font-weight:800;color:#173a50}
.chip{display:inline-block;padding:5px 11px;background:#e7f4f6;color:#147184;border-radius:22px;font-size:11px;font-weight:800;margin-right:7px}
.chip.warn{color:#ae654a;background:#fff0e5}
.flowbar{background:white;border:1px solid #dbeaf1;border-radius:17px;padding:16px 20px;line-height:2.8;color:#1b4b60;margin-bottom:20px;font-size:12px;font-weight:750;box-shadow:0 7px 24px #123b520a}
.feature-teal,.feature-blue,.feature-violet,.feature-green{border-radius:18px;padding:25px 28px 17px;color:white;min-height:155px;box-shadow:0 12px 24px #103e5019}
.feature-teal{background:linear-gradient(110deg,#02768d,#07aeb5)}.feature-blue{background:linear-gradient(110deg,#1761b0,#358ed2)}.feature-violet{background:linear-gradient(110deg,#5e55bf,#8e74c9)}.feature-green{background:linear-gradient(110deg,#087e7c,#18ada0)}
.feature-heading{font-size:25px;font-weight:800;margin-bottom:8px}.feature-sub{font-size:13px;line-height:1.7;color:#f4feff}
.incident{background:#fff;border:1px solid #d9e8ef;border-left:4px solid #e08a52;border-radius:13px;padding:18px 21px;margin:8px 0}
.incident strong{color:#1c3c50;font-size:16px}.incident small{display:block;color:#688195;margin-top:8px;line-height:1.6}
.foot{margin-top:28px;color:#8aa1ac;font-size:11px}
</style>""",unsafe_allow_html=True)

with st.sidebar:
    st.markdown('<div class="logo">Biz<span>Pilot</span></div>',unsafe_allow_html=True)
    st.caption('经营分析与决策工作台 · 公开版')
    st.divider()
    for label,icon in [('首页 / 自由提问','⌂'),('功能导航','▦'),('经营概览','▥'),('深度诊断','⌕'),('Agent 调查','✦'),('证据审计','✓'),('Olist 真实数据','◈')]:
        st.button(f'{icon}  {label}',key='nav_'+label,on_click=go,args=(label,),use_container_width=True,
                  type='primary' if st.session_state['page']==label else 'secondary')
    st.divider()
    source_label = {
        'Olist 真实数据': 'OLIST WORKSPACE',
    }.get(st.session_state['page'], 'SYNTHETIC DEMO' if DB == DEMO_DB else 'IMPORTED CSV')
    st.caption(f'LOCAL DATA · {source_label} · V1.0-B.1')

# Olist runs in an isolated historical workspace; it never substitutes for synthetic daily_metrics.
if st.session_state['page']=='Olist 真实数据':
    header('OLIST · SELLER INVESTIGATION','Olist 电商经营诊断',
           '基于真实公开订单的五轮商家履约调查。')
    public_seller_workspace(ROOT/'public_case'/'olist_seller_verified.json')
    st.stop()

page=st.session_state['page']
initialize_demo()
mode=st.session_state.get('mode','证据驱动 Agent（推荐）')
question=st.session_state['question']
mtime=DB.stat().st_mtime_ns
try:
    df=load_data(str(DB),mtime)
    deep=deep_dive(str(DB),mtime) if DB==DEMO_DB and page in ['Agent 调查','证据审计','深度诊断'] else None
except (sqlite3.Error,ValueError,KeyError) as exc:
    st.error(f'读取数据失败：{exc}');st.stop()

st.markdown('<div class="topbar"><strong>Biz<span style="color:#119bb2">Pilot</span> / '+e(page)+'</strong><span>BUSINESS ANALYTICS · EVIDENCE FIRST</span></div>',unsafe_allow_html=True)

if page=='首页 / 自由提问':
    header('BIZPILOT · BUSINESS DECISION INTELLIGENCE', '像商业分析师一样提问，让 BizPilot 带你找到答案',
           '输入经营问题，查看分析计划、业务证据、调查缺口与可执行的下一步建议。')
    st.markdown('<div class="sectiontitle">提出你的经营问题</div>',unsafe_allow_html=True)
    with st.form('home_form'):
        q=st.text_area('自由提问',value=question,height=105,placeholder='例如：为什么上周收入下降？主要损失来自哪些渠道和品类？')
        submitted=st.form_submit_button('✦  开始分析',type='primary',use_container_width=True)
    if submitted:
        if q.strip():ask_question(q.strip());st.rerun()
        else:st.warning('请先输入具体的经营问题。')
    st.caption('支持基础经营指标与全局异常扫描；演示数据还提供模拟广告、库存和退款表。超出字段范围时会明确说明。')
    st.markdown('<div class="sectiontitle">示例问题 · 点击即可开始调查</div>',unsafe_allow_html=True)
    prompts=['最近一周有什么经营异常？','East / Paid / Electronics 的流量变化如何？','广告曝光和投放花费有什么变化？','退款金额在哪些品类最高？']
    for c,q in zip(st.columns(4),prompts):
        with c:
            if st.button(q,key='prompt_'+q,use_container_width=True):ask_question(q);st.rerun()
    st.markdown('<div class="flowbar"><b>经营分析闭环</b>　　发现异常　→　证据是否充分　→　自主下钻　→　识别遗漏　→　再次核验　→　行动建议</div>',unsafe_allow_html=True)
    left,right=st.columns([1.4,1],gap='large')
    with left:
        card('最近分析记录','记录的是本次会话已提交的问题；正式持久化历史记录将在后续版本添加。','RECENT QUESTIONS')
        if st.session_state['history']:
            for i,item in enumerate(st.session_state['history'][:4]):
                if st.button('↗  '+item,key=f'history_{i}',use_container_width=True):ask_question(item);st.rerun()
        else:st.info('暂无历史提问。提交第一个问题后将显示在此处。')
    with right:
        card('分析能力','收入趋势、分组贡献、Shapley 数值分解和带证据门禁的本地 Agent。','CAPABILITIES')
        if st.button('▦  打开功能导航',use_container_width=True,type='primary'):go('功能导航');st.rerun()

elif page=='功能导航':
    header('BIZPILOT · WORKSPACE MENU','功能导航中心','根据分析目标选择工作区；四个模块围绕同一模拟数据集协同分析。')
    st.markdown('<div class="flowbar"><b>分析工作流程</b>　　发现异常　→　证据充分性判断　→　自主下钻　→　识别遗漏　→　再次核验　→　行动建议</div>',unsafe_allow_html=True)
    cards=[('经营概览','查看核心 KPI、经营趋势及业务结构','feature-teal','▥'),('深度诊断','定位重点损失、指标贡献与核验方向','feature-blue','⌕'),('Agent 调查','模型驱动的工具核查与证据门禁','feature-violet','✦'),('证据审计','数据质量、执行轨迹和结果导出','feature-green','✓')]
    for pair in (cards[:2],cards[2:]):
        for col,(target,desc,style,icon) in zip(st.columns(2,gap='large'),pair):
            with col:
                st.markdown(f'<div class="{style}"><div class="feature-heading">{e(icon)}　{e(target)}</div><div class="feature-sub">{e(desc)}</div></div>',unsafe_allow_html=True)
                if st.button('进入'+target+'　→',key='menu_'+target,type='primary',use_container_width=True):go(target);st.rerun()
    st.markdown('<div class="sectiontitle">推荐分析路径</div>',unsafe_allow_html=True)
    st.info('经营概览 → 深度诊断 → Agent 调查 → 证据审计。也可以从首页直接发起问题。')
    if st.session_state['history']:
        st.markdown('<div class="sectiontitle">继续最近任务</div>',unsafe_allow_html=True)
        if st.button('继续分析：'+st.session_state['history'][0],use_container_width=True):ask_question(st.session_state['history'][0]);st.rerun()

elif page=='经营概览':
    header('BIZPILOT / BUSINESS OVERVIEW','经营概览','从整体表现到关键变化，快速理解业务现状，并将异常带入下一步分析。')
    st.markdown('<span class="chip">'+('SYNTHETIC DEMO' if DB==DEMO_DB else 'IMPORTED CSV')+'</span><span class="chip">SQLITE · READ ONLY</span><span class="chip warn">NOT CAUSAL ANALYSIS</span>',unsafe_allow_html=True)
    st.markdown('<div class="sectiontitle">分析条件</div>',unsafe_allow_html=True)
    cfg=st.session_state['scope']
    with st.form('overview_filters'):
        a,b,c,d=st.columns(4)
        period=a.selectbox('时间范围',['近7天','近30天','全部数据'],index=['近7天','近30天','全部数据'].index(cfg['period']))
        regions=['全部']+sorted(df.region.unique().tolist())
        channels=['全部']+sorted(df.channel.unique().tolist())
        categories=['全部']+sorted(df.category.unique().tolist())
        region=b.selectbox('地区',regions,index=regions.index(cfg['region']) if cfg['region'] in regions else 0)
        channel=c.selectbox('渠道',channels,index=channels.index(cfg['channel']) if cfg['channel'] in channels else 0)
        category=d.selectbox('品类',categories,index=categories.index(cfg['category']) if cfg['category'] in categories else 0)
        compare=st.checkbox('对比上一等长周期',value=cfg['compare'])
        applied=st.form_submit_button('应用筛选　→',type='primary')
        if applied:st.session_state['scope']={'period':period,'region':region,'channel':channel,'category':category,'compare':compare};st.rerun()
    cfg=st.session_state['scope']
    length={'近7天':7,'近30天':30,'全部数据':None}[cfg['period']]
    cf,pf,meta=period_window(df,length,compare=cfg['compare'])
    cf=filter_frame(cf,cfg['region'],cfg['channel'],cfg['category'])
    pf=filter_frame(pf,cfg['region'],cfg['channel'],cfg['category']) if pf is not None else None
    a=metrics(cf);b=metrics(pf) if pf is not None else None
    st.caption(f'数据截至 {df.day.max().date()} · 当前范围 {meta["current_start"].date() if meta["current_start"] is not None else "—"} 至 {meta["current_end"].date() if meta["current_end"] is not None else "—"} · 所有组件使用相同筛选条件')
    if meta['notice']:st.info(meta['notice'])
    if cf.empty:st.warning('当前筛选范围暂无数据，请放宽筛选条件。')
    else:
        st.markdown('<div class="sectiontitle">核心经营指标</div>',unsafe_allow_html=True)
        metric_defs=[('营业收入','revenue',0,''),('完成订单','orders',0,''),('访问流量','visits',0,''),('访问转化率','conversion',2,'%'),('平均客单价','aov',2,'' )]
        cols=st.columns(5)
        for col,(label,key,nd,suffix) in zip(cols,metric_defs):
            with col:
                curr=a[key];prev=b[key] if b else None
                delta=metric_change(curr,prev,key)
                if key=='conversion':d=f'{delta:+.2f} pp' if delta is not None else None
                else:d=change(delta) if delta is not None else None
                st.metric(label,(num(curr,nd)+suffix) if curr is not None else '—',d)
        with st.expander('查看指标口径与计算公式'):
            st.markdown('''**营业收入** = `SUM(revenue)`（演示数据不含真实退款或税费口径）  
**完成订单** = `SUM(orders)`  
**访问流量** = `SUM(visits)`  
**转化率** = `SUM(orders) / SUM(visits)`  
**平均客单价** = `SUM(revenue) / SUM(orders)`。转化率变动以百分点 pp 表示，其他变动以相对百分比表示。''')
        st.markdown('<div class="sectiontitle">经营趋势与业务结构</div>',unsafe_allow_html=True)
        l,r=st.columns([1.55,1],gap='large')
        with l:
            card('经营趋势','每日聚合后的指标趋势；可切换分析对象。','REVENUE / ORDERS / TRAFFIC')
            metric=st.segmented_control('趋势指标',['收入','订单','流量','转化率','客单价'],default='收入',key='trend_switch')
            name_to_key={'收入':'revenue','订单':'orders','流量':'visits','转化率':'conversion','客单价':'aov'}
            trend=latest_daily_trend(cf,name_to_key[metric or '收入'])
            st.line_chart(trend.set_index('day')['value'],height=295,color='#1693a9')
            st.caption('该趋势基于当前数据窗口，不作季节性调整或因果推断。')
        with r:
            card('业务结构','按地区、渠道和品类查看当前期收入规模。','SEGMENT COMPOSITION')
            dim=st.segmented_control('分析维度',['地区','渠道','品类'],default='地区',key='dim_switch')
            key={'地区':'region','渠道':'channel','品类':'category'}[dim or '地区']
            group=cf.groupby(key)['revenue'].sum().sort_values(ascending=True)
            st.bar_chart(group,height=295,horizontal=True,color='#1595ad')
            st.caption('若需定位变化来源，请切换到下方分组变化贡献。')
        st.markdown('<div class="sectiontitle">变化贡献与关键异常</div>',unsafe_allow_html=True)
        if b:
            d=drivers(a,b)
            items=st.columns(3)
            for col,k in zip(items,['visits','conversion','aov']):
                with col:card(LABEL[k]+'贡献 '+num(d[k]),'基于收入=访问量×转化率×客单价的 Shapley 恒等式拆解。',k.upper()+' EFFECT')
            candidates=anomaly_candidates(cf,pf,top_n=5)
            if candidates:
                for i,item in enumerate(candidates[:3],1):
                    label=' / '.join(str(item[x]) for x in ('region','channel','category'))
                    st.markdown(f'<div class="incident"><div class="eyebrow">PRIORITY {i:02}</div><strong>{e(label)} · {num(item["delta"])} （{change(item["change_pct"])}）</strong><small>主要负向指标贡献：{LABEL[item["primary"]]} {num(item["drivers"][item["primary"]])}。这是数值贡献而非已证实的业务原因。</small></div>',unsafe_allow_html=True)
                if st.button('进入深度诊断　→',type='primary'):go('深度诊断');st.rerun()
                st.caption('深度诊断将继承上述筛选范围；原有Agent使用固定相邻七日数据，若分析范围不同会明确提示。')
            else:st.success('当前筛选范围没有收入下降的细分组合。')
        else:st.info('没有可靠的完整对比期，本页仅展示当前指标与趋势；不生成虚假变化贡献。')
        if st.button('✦  使用 Agent 进一步调查',type='primary',use_container_width=True):
            focus=f'{cfg["region"]}地区、{cfg["channel"]}渠道、{cfg["category"]}品类' if any(cfg[k]!='全部' for k in ['region','channel','category']) else '全部业务'
            st.session_state['question']=f'请分析{focus}在{cfg["period"]}内的经营表现，提供证据并说明调查不足。'
            st.session_state['agent_question_input']=st.session_state['question']
            st.session_state.pop('dynamic_answer',None)
            go('Agent 调查');st.rerun()

elif page=='深度诊断':
    header('DEEP DIAGNOSIS','深度诊断','按收入变化金额排序，核验重点细分异常和指标贡献；所有数值来自SQLite。')
    cfg=st.session_state['scope'];length={'近7天':7,'近30天':30,'全部数据':None}[cfg['period']]
    cf,pf,meta=period_window(df,length,compare=cfg['compare'])
    cf=filter_frame(cf,cfg['region'],cfg['channel'],cfg['category'])
    pf=filter_frame(pf,cfg['region'],cfg['channel'],cfg['category']) if pf is not None else None
    st.caption('继承经营概览筛选：'+str(cfg)+' · 数据截至 '+str(df.day.max().date()))
    if DB!=DEMO_DB:
        st.info('已切换到导入的CSV。本页的固定36分组事件模板仅适配内置数据；请在「经营概览」查看当前CSV指标，或从「Agent调查」运行自由问题异常扫描。')
        st.stop()
    if pf is None:st.warning('当前范围无法形成可靠对比，请返回经营概览选择近7天或近30天并开启对比。')
    elif cf.empty:st.info('当前筛选条件下没有有效数据。')
    else:
        c=metrics(cf);p=metrics(pf);d=drivers(c,p)
        st.markdown('<div class="sectiontitle">调查摘要</div>',unsafe_allow_html=True)
        card('净收入变化 '+num(c['revenue']-p['revenue'])+'（'+change(metric_change(c['revenue'],p['revenue'],'revenue'))+'）',
             '各互斥细分组合按绝对收入下降排序；指标归因仅为数学贡献，不代表已查明真实业务根因。','DIAGNOSTIC BRIEF')
        for key in ['region','channel','category']:
            with st.expander({'region':'地区贡献','channel':'渠道贡献','category':'品类贡献'}[key]):
                st.dataframe(breakdown(cf,pf,key),hide_index=True,use_container_width=True)
        candidates=anomaly_candidates(cf,pf,top_n=10)
        for idx,item in enumerate(candidates,1):
            label=' / '.join(str(item[k]) for k in ('region','channel','category'))
            st.markdown(f'<div class="incident"><div class="eyebrow">PRIORITY {idx:02}</div><strong>{e(label)}　·　{num(item["delta"])}　({change(item["change_pct"])})</strong><small>主要贡献指标：{LABEL[item["primary"]]}；按金额损失排序，不按跌幅排序。</small></div>',unsafe_allow_html=True)
            with st.expander('查看细分贡献与待核实证据 · '+label):
                st.dataframe(pd.DataFrame([{'指标':LABEL[k],'收入变化贡献':round(v,2)} for k,v in item['drivers'].items()]),hide_index=True,use_container_width=True)
                tips={'visits':'核查渠道曝光、点击、流量采集和入口变更。','conversion':'核查页面漏斗、库存、支付流程和价格展示。','aov':'核查SKU价格结构、折扣、退款与大单。'}
                st.write('建议核查：'+tips[item['primary']]);st.caption('演示环境已有合成广告、库存及退款表，可用自由提问核查相关指标；真实原因仍需要可靠业务来源。')
        if not candidates:st.success('该分析范围内没有收入下降的细分组合。')
        if st.button('✦  在 Agent 中继续调查',type='primary'):go('Agent 调查');st.rerun()

if page == 'Agent 调查':
    header('AGENT INVESTIGATION','Agent 调查','跨业务数据源调查 · 实际证据 · 反证反思 · 逐步确认下一步。')
    question=st.text_area('本次调查问题',value=st.session_state['question'],height=98,key='agent_question_input')
    st.session_state['question']=question
    st.caption('当前来源：'+('内置演示数据库（含模拟辅助表）' if DB==DEMO_DB else '用户导入CSV')+' · 可用表：'+', '.join(k for k,v in source_registry(DB).items() if v))
    st.markdown('<div class="sectiontitle">按问题启动数据调查</div>',unsafe_allow_html=True)
    st.caption('普通指标提问、全局异常扫描和辅助数据核查走不同的数据路径；所有结论可复算。')

    if st.session_state.pop('pending_query',False):
        try:
            aux=analyze_extra_question(DB,question)
            st.session_state['dynamic_answer']=aux if aux is not None else analyze_question(df,question)
            st.session_state['dynamic_question_text']=question
        except (ValueError,KeyError,TypeError,ZeroDivisionError,sqlite3.Error) as exc:
            st.error('自动查询失败：'+str(exc))
    if st.button('▥  查询当前问题',type='primary',key='dynamic_question_button'):
        try:
            extra=analyze_extra_question(DB,question)
            st.session_state['dynamic_answer']=extra if extra is not None else analyze_question(df,question)
            st.session_state['dynamic_question_text']=question
        except (ValueError,KeyError,TypeError,ZeroDivisionError,sqlite3.Error) as err:st.error('查询失败：'+str(err))
    if st.session_state.get('dynamic_question_text') != question:st.session_state.pop('dynamic_answer',None)
    ans=st.session_state.get('dynamic_answer')
    if ans is not None:
        if ans.get('type')=='unsupported':
            st.warning(ans['reason'])
        elif ans.get('type')=='auxiliary':
            st.success(f'已查询 {ans["table"]} · {ans["metric_label"]}；观测窗口 {ans["start"]} 至 {ans["end"]}')
            x,y,z=st.columns(3)
            x.metric('本期'+ans['metric_label'],num(ans['current'],2))
            y.metric('上期'+ans['metric_label'],num(ans['previous'],2))
            z.metric('指标变化',num(ans['current']-ans['previous'],2))
            st.dataframe(pd.DataFrame(ans['groups']),hide_index=True,use_container_width=True)
            st.warning(ans['notice'])
            st.download_button('导出辅助数据分析',json.dumps(ans,ensure_ascii=False,indent=2),file_name='bizpilot_auxiliary_result.json',mime='application/json')
        elif not ans.get('supported'):
            st.warning(ans['reason'])
        elif ans.get('empty'):
            st.warning('当前问题所选地区、渠道或品类没有可用数据。')
        else:
            met=ans['metric']; labels={'revenue':'营业收入','orders':'订单量','visits':'访问流量','conversion':'转化率','aov':'客单价'}
            current_val=ans['current'][met];suffix='%' if met=='conversion' else ''
            st.metric('本期'+labels[met],num(current_val,2 if met in ('conversion','aov') else 0)+suffix,
                      (f'{ans["delta"]:+.2f} pp' if met=='conversion' else change(ans['delta'])) if ans['delta'] is not None else None)
            st.caption('解析结果：指标 '+labels[met]+' · 筛选 '+str(ans['filters'])+' · 分组 '+str(ans['group_by'])+' · 数据集截至 '+str(ans['meta']['current_end'].date()))
            if ans['meta']['notice']:st.info(ans['meta']['notice'])
            st.markdown('**指标趋势（SQL数据聚合）**')
            st.line_chart(ans['trend'].set_index('day')['value'],color='#1496ac',height=220)
            if ans['groups'] is not None:
                st.markdown('**业务分组明细**')
                group_df=pd.DataFrame(ans['groups'])
                st.dataframe(group_df.rename(columns={'group':'分组','current':'本期指标','previous':'上期指标','change_pct_or_pp':'变化（%或pp）','visits':'访问','orders':'订单','revenue':'收入'}),hide_index=True,use_container_width=True)
                groups=[row for row in ans['groups'] if row['current'] is not None]
                if groups:
                    asked_low=any(k in question for k in ('最低','最差','最少','下降最大'))
                    asked_growth=any(k in question for k in ('增长最快','增长最多','增幅最大'))
                    if asked_growth:
                        eligible=[row for row in groups if row['change_pct_or_pp'] is not None]
                        selected=max(eligible,key=lambda x:x['change_pct_or_pp']) if eligible else None
                        metric_name='增长最快'
                    else:
                        selected=(min if asked_low else max)(groups,key=lambda x:x['current'])
                        metric_name='最低' if asked_low else '最高'
                    if selected:
                        st.success('基于当前数据：'+selected['group']+' 的'+labels[met]+metric_name+'（本期 '+num(selected['current'],2)+'）。')
            if ans.get('intent')=='anomaly_scan':
                st.markdown('**异常扫描结果：按损失金额排序**')
                if ans['candidates']:
                    rows=[{'地区':x['region'],'渠道':x['channel'],'品类':x['category'],
                       '收入变化':round(x['delta'],2),'变化率%':round(x['change_pct'],2),
                       '主要指标贡献':LABEL[x['primary']]} for x in ans['candidates']]
                    st.dataframe(pd.DataFrame(rows),hide_index=True,use_container_width=True)
                    st.warning('检测到 '+str(len(ans['candidates']))+' 个收入负向变化组合（最多展示前10个）。这些是按金额变化排序的候选异常，不代表统计显著性，也不是已经证实的业务原因。')
                    if DB==DEMO_DB:
                        st.info('下一步可核查：投放/曝光、库存缺货、退款数据。请输入“广告曝光有什么变化”“哪些品类退款金额最高”等具体问题。')
                else:st.success('该窗口未识别出收入负向变化的细分组合。')
            if ans['candidates'] and met=='revenue' and ans.get('intent')!='anomaly_scan':
                st.markdown('**优先调查的损失分组**')
                for cand in ans['candidates'][:2]:
                    st.write('• '+ '/'.join(str(cand[d]) for d in ('region','channel','category'))+ ' 收入变化 '+num(cand['delta'])+'；主要贡献指标为 '+LABEL[cand['primary']])
            st.info('业务判断边界：本页提供与当前问题匹配的数据事实和指标变化，尚不能仅凭这些观察值证明业务根因。建议结合渠道曝光、库存、促销和埋点记录继续核查。')
            st.download_button('导出问题解析与数值结果',json.dumps({k:v for k,v in ans.items() if k!='trend'},ensure_ascii=False,indent=2,default=str),file_name='bizpilot_question_result.json',mime='application/json')
    st.divider()
    st.markdown('<div class="sectiontitle">AI 商业调查 · 从发现到决策</div>',unsafe_allow_html=True)
    st.caption('点击开始后，先给出真实的跨表核查结果；每一步由你决定继续调查、检查反证或形成行动方案。模拟数据与模型推断严格区分。')
    st.info('这条流程目前针对收入变化开展跨数据源调查；其他问题使用上方的动态指标查询。若尚未接入本地模型，使用可复算的证据工作流而不冒充模型自主推理。')
    if st.button('✦  开始调查 · 生成第一份证据简报',type='primary',key='start_cross_source'):
        try:
            with st.spinner('正在扫描经营分组，并关联广告、库存、退款、优惠与支付证据…'):
                case_result=investigate_case(DB,question,days=7,max_cases=3)
            st.session_state['case_investigation']={'result':case_result,'visible':1,'phase':'review','model_review':None,'id':str(DB)+'|'+question}
            st.rerun()
        except (ValueError,sqlite3.Error,KeyError,TypeError) as exc:
            st.error('跨数据源调查未能完成：'+str(exc))
    session=st.session_state.get('case_investigation')
    if session and session.get('id')!=str(DB)+'|'+question:
        st.session_state.pop('case_investigation',None)
        session=None
    if session:
        cr=session['result']
        st.markdown('<div class="sectiontitle">调查结论 · 当前证据</div>',unsafe_allow_html=True)
        current_period=cr['periods']['current'];previous_period=cr['periods']['previous']
        st.caption(f'观察窗口：{previous_period[0]}—{previous_period[1]} 对比 {current_period[0]}—{current_period[1]} · 扫描 {cr["leaves_scanned"]} 个互斥经营组合')
        a,b,c=st.columns(3)
        a.metric('本周收入',num(cr['total']['after'],0),f'{cr["total"]["delta"]:,.0f}')
        b.metric('收入下降的组合',cr['negative_leaves'])
        c.metric('已核查的优先组合',f'{session["visible"]}/{len(cr["cases"])}')
        st.markdown(f'<div class="bp-card"><div class="eyebrow">ANALYST BRIEF · GROUNDED FACTS</div><h3>收入变化 {num(cr["total"]["delta"])}，优先核查最大损失的业务组合</h3><p>先比较互斥地区 × 渠道 × 品类的损失，再拆解流量、转化率、客单价，最后关联辅助业务证据。辅助数据是合成演示，不证明因果。</p></div>',unsafe_allow_html=True)
        for idx,item in enumerate(cr['cases'][:session['visible']],1):
            hypo=item['hypothesis']
            st.markdown(f'<div class="incident"><div class="eyebrow">INVESTIGATION {idx:02} · {e(item["actions"]["priority"])} · {e(item["driver"])}优先</div><strong>{e(item["segment"])} · 收入变化 {num(item["delta"])}</strong><small>从 {num(item["before"])} 降至 {num(item["after"])}；变化 {change(item["pct"])}（本项变化率是相对上期的下降幅度）。</small></div>',unsafe_allow_html=True)
            st.markdown('**第一层判断｜财务指标变化由什么贡献？**')
            drows=[{'指标':{'visits':'流量','conversion':'转化率','aov':'客单价'}[key], '对收入变化的金额贡献':float(val)} for key,val in item['drivers'].items()]
            st.dataframe(pd.DataFrame(drows),hide_index=True,use_container_width=True)
            st.markdown('**第二层判断｜跨数据源证据是否支持这个方向？**')
            st.dataframe(pd.DataFrame([{'交叉验证':x['label'],'观察变化':x['value'],'证据状态':x['status'],'数据来源':x['source']} for x in hypo['checks']]),hide_index=True,use_container_width=True)
            st.markdown('**Agent式反思｜哪些结论还不能下？**')
            if hypo['contradictory']:
                contrary='另有 '+str(hypo['contradictory'])+' 项辅助指标与预期方向不一致，不能忽略这些反证。'
            else:contrary='当前未出现相反方向的已覆盖指标，但这不等于原因已被证实。'
            st.warning(f'现有辅助证据：{hypo["status"]}。{contrary} 同步变化可能由共同因素造成；必须核查真实业务日志、时间先后与统计口径。')
            st.markdown('**下一步商业行动｜要查什么、谁来查、如何验收？**')
            act=item['actions']
            st.write(f'**责任团队：** {act["owner"]}')
            st.write(f'**核查动作：** {act["task"]}')
            st.write(f'**验收证据：** {act["acceptance"]}')
            st.caption('操作建议仅供人工审批；不会自动修改经营参数。')
        st.divider()
        st.markdown('### 你希望 Agent 下一步做什么？')
        st.caption('已经展示的发现不会丢失，继续调查时补充其他重点分组，直到完成多维证据检查。')
        next_col,export_col=st.columns([1.15,1],gap='small')
        with next_col:
            if session['visible']<len(cr['cases']):
                if st.button('继续调查下一处异常',type='primary',use_container_width=True,key='case_continue'):
                    st.session_state['case_investigation']['visible']+=1
                    st.rerun()
            else:
                st.success('当前优先级队列已核查完毕。')
        with export_col:
            st.download_button('下载可核验调查报告',json.dumps(cr,ensure_ascii=False,indent=2),file_name='bizpilot_investigation.json',mime='application/json',use_container_width=True)
        if session.get('model_review'):
            st.markdown('### Qwen3 模型反思（非事实来源）')
            st.write(session['model_review'])
            st.caption('模型补充的是解释和核查建议；所有数值以查询结果为准。')
        if session['visible']<len(cr['cases']):
            next_item=cr['cases'][session['visible']]
            st.info('待确认的下一步：是否继续核查 '+next_item['segment']+'？当前已观察到其收入变化 '+num(next_item['delta'])+'，但该组合的跨表证据尚未在本次会话展示。')
        else:
            st.markdown('**本轮调查结束：可供人工审批的建议**')
            st.success('已检查优先损失分组，并记录证据支持、反证与数据缺口。建议先收集真实业务日志，再决定是否调整投放、促销或商品策略。')
        st.caption('证据限制：'+ '；'.join(cr['limitations']))
    else:
        st.info('还没有启动跨数据源调查。点击上方「开始调查」后，将首先展示一条具体异常、财务拆解、交叉证据和待确认的下一步。')

if page == '证据审计':
    header('EVIDENCE AUDIT','证据审计','核查计算口径、数据质量、工具执行轨迹和可导出证据。')
    st.caption('本页核验当前数据源最近两周的独立指标计算；具体查询范围详见各模块。')
    st.markdown('<div class="bp-section">数据可信度与证据追踪</div>',unsafe_allow_html=True)
    if DB!=DEMO_DB:
        st.info('当前是用户导入的CSV。固定日期、固定分组的审计模板不能用于此数据源；基本表结构与数值合法性已在导入时验证。')
        st.stop()
    q=deep['data_quality']
    qc1,qc2,qc3=st.columns(3)
    qc1.metric('核验数据行数',q['rows'])
    qc2.metric('数据观察天数',q['days'])
    qc3.metric('无效记录',q['invalid_rows'])
    st.write('**独立贡献加总校验**', '通过' if deep['reconciles'] else '未通过')
    st.caption('收入公式：Revenue = Visits × (Orders/Visits) × (Revenue/Orders)。')
    st.info('深度诊断为36个互斥细分组合上的确定性计算；不使用LLM补写数值。当前未评估季节性、统计置信区间或外部原因。')
    result=st.session_state.get('agent_result')
    if st.session_state.get('case_investigation'):
        st.markdown('**跨源调查证据与决策记录**')
        st.json(st.session_state['case_investigation']['result'])
    if result:
        if result.get('mode')=='hybrid evidence-guided agent':
            st.markdown('**混合Agent核验轨迹**')
            for d in result['decisions']:
                with st.expander(f"{d['step']}. {d['selected_by']} · {d['segment']}"):
                    st.json(d)
        events=result.get('events') or [{'step':i,'tool':item.get('tool'),'args':item.get('args'),'result':item.get('result'),'ok':True} for i,item in enumerate(result.get('traces',[]),1)]
        st.markdown('<div class="bp-section">Agent 工具调用记录</div>',unsafe_allow_html=True)
        for item in events:
            with st.expander(f"{'✓' if item.get('ok',True) else '!'} {item.get('step','—')}. {item.get('tool','unknown')}"):
                st.write('输入参数');st.json(item.get('args') or {})
                st.write('工具结果');st.json(item.get('result'))
        st.download_button('导出Agent调查记录',json.dumps(result,ensure_ascii=False,indent=2),file_name='bizpilot_agent_trace.json',mime='application/json')
    st.download_button('导出独立经营诊断数据',json.dumps(deep,ensure_ascii=False,indent=2),file_name='bizpilot_verified_diagnosis.json',mime='application/json')

st.markdown('<div class="foot">BizPilot v0.8 · Local data workbench · Reproducible figures · Synthetic auxiliaries are not causal evidence</div>',unsafe_allow_html=True)

"""Ollama-powered iterative read-only investigation agent (not a static workflow).

A model proposes tools, gets grounded observations, and chooses whether to continue.
Safety: local URL only, fixed allowlist, validated args, bounded steps and output.
"""
from __future__ import annotations
import json
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse
from .tools import BusinessTools, DIMENSIONS, METRICS

DEFAULT_URL = 'http://127.0.0.1:11434'
DEFAULT_MODEL = 'qwen3:4b'
MAX_STEPS = 12

TOOL_DEFS = [
 {'type':'function','function':{'name':'data_quality','description':'Check if both seven-day periods are complete and valid.',
   'parameters':{'type':'object','properties':{}}}},
 {'type':'function','function':{'name':'metric_overview','description':'Compare revenue, visits or orders for the complete business.',
   'parameters':{'type':'object','properties':{'metric':{'type':'string','enum':list(METRICS)}},'required':['metric']}}},
 {'type':'function','function':{'name':'breakdown','description':'Split metric change across a dimension. Optional filters let you narrow to one segment.',
   'parameters':{'type':'object','properties':{'metric':{'type':'string','enum':list(METRICS)},
    'dimension':{'type':'string','enum':list(DIMENSIONS)},
    'filters':{'type':'object','properties':{k:{'type':'string'} for k in DIMENSIONS},'additionalProperties':False}},
    'required':['metric','dimension']}}},
 {'type':'function','function':{'name':'segment_metrics','description':'Get revenue, orders, visits, conversion and average order value for a filtered segment; use to verify the change mechanism.',
   'parameters':{'type':'object','properties':{'filters':{'type':'object','properties':{k:{'type':'string'} for k in DIMENSIONS},'additionalProperties':False}}}}}
]

SYSTEM = '''你是 BizPilot 的本地经营分析 Agent。必须通过工具获取数值，不能编造数字。
本次调查仅比较 2026-10-16 至 10-22 与 2026-10-23 至 10-29；指标为 revenue, orders, visits。
可用的地域：East, West, North, South；渠道：Organic, Paid, Referral；品类：Electronics, Home, Beauty。
调查步骤自行决定，不要机械遍历全部组合；最初先检查 data_quality 与 metric_overview(revenue)，然后基于查询反馈，选择最有信息增益的 breakdown 和 segment_metrics。
优先找出收入损失大的细分业务，但也尝试寻找第二个独立的可疑细分异常。验证 visits, conversion, aov 的变化来描述指标机制。
发现指标异常不代表证明业务因果根源。数据有缺陷时必须告知。不要把未经工具证实的结论写成事实。
当证据充分或接近调用预算上限时停止调用工具，以中文给出：总体变化；最多3个有数字和筛选条件的发现；证据限制；下一步核查建议。
如果没有足够证据，请明确写出。'''

class LocalAgentError(RuntimeError):
    pass


def _local_url(base):
    parsed = urlparse(base)
    if parsed.scheme != 'http' or parsed.hostname not in ('localhost', '127.0.0.1', '::1') or parsed.username or parsed.password:
        raise ValueError('为保护数据，仅允许连接本机 Ollama (localhost / 127.0.0.1)。')
    return base.rstrip('/')


def _request(base, endpoint, payload=None, timeout=20):
    url = _local_url(base) + endpoint
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers={'Content-Type':'application/json'},
                                 method='POST' if data is not None else 'GET')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.load(resp)
    except urllib.error.HTTPError as exc:
        detail = exc.read(400).decode('utf-8', errors='replace')
        raise LocalAgentError(f'Ollama HTTP {exc.code}: {detail}') from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise LocalAgentError(f'无法连接本地 Ollama：{exc}') from exc


def ollama_status(base=DEFAULT_URL, requester=_request):
    try:
        response = requester(base, '/api/tags', timeout=3)
        return {'online':True, 'models':[m.get('name','') for m in response.get('models',[])]}
    except (LocalAgentError, ValueError, OSError) as exc:
        return {'online':False,'models':[], 'error':str(exc)}


def _validate(name, arguments):
    if name not in ('data_quality','metric_overview','breakdown','segment_metrics'):
        raise ValueError(f'不允许调用的工具: {name}')
    if not isinstance(arguments, dict):
        raise ValueError('工具参数必须为JSON对象')
    if name == 'data_quality':
        if arguments: raise ValueError('data_quality 不接受参数')
        return {}
    allowed = {'metric'} if name == 'metric_overview' else ({'metric','dimension','filters'} if name == 'breakdown' else {'filters'})
    if set(arguments)-allowed:
        raise ValueError('不支持的工具参数')
    if name in ('metric_overview','breakdown') and arguments.get('metric') not in METRICS:
        raise ValueError('指标不在白名单中')
    if name == 'breakdown' and arguments.get('dimension') not in DIMENSIONS:
        raise ValueError('维度不在白名单中')
    filters = arguments.get('filters', {})
    if filters is None: filters = {}
    if not isinstance(filters,dict) or any(k not in DIMENSIONS or not isinstance(v,str) or len(v)>80 for k,v in filters.items()):
        raise ValueError('筛选条件不合法')
    if 'filters' in arguments: arguments = {**arguments,'filters':filters}
    return arguments


def _args(raw):
    if isinstance(raw,dict): return raw
    if isinstance(raw,str): return json.loads(raw)
    raise ValueError('无法解析工具参数')


def investigate_local(db_path, question='为什么收入下降？', model=DEFAULT_MODEL,
                      base=DEFAULT_URL, max_steps=MAX_STEPS, requester=_request):
    """Run a bounded, dynamically planned conversation against a local tool-using model.

    requester injection supports repeatable offline testing with a mocked Ollama.
    """
    _local_url(base)
    if not 1 <= max_steps <= 30: raise ValueError('max_steps 必须介于 1 与 30')
    if not isinstance(question,str) or len(question)>2000: raise ValueError('问题过长')
    tools = BusinessTools(db_path)
    messages = [{'role':'system','content':SYSTEM},{'role':'user','content':question}]
    events=[]; model_calls=0; start=time.monotonic(); last_content=''; steps=0
    usage={'prompt_eval_count':0,'eval_count':0}
    # A tool turn can contain several requested calls: strictly enforce max_steps across all.
    for turn in range(max_steps+1):
        payload={'model':model,'messages':messages,'tools':TOOL_DEFS if steps < max_steps else [],
                 'stream':False,'options':{'temperature':0},'keep_alive':'5m'}
        response=requester(base,'/api/chat',payload=payload,timeout=180)
        model_calls+=1
        for k in usage: usage[k]+=response.get(k,0) or 0
        message=response.get('message') or {}
        content=message.get('content') or ''
        if content: last_content=content
        calls=message.get('tool_calls') or []
        if not calls or steps>=max_steps:
            return {'version':'0.3.0','mode':'local Ollama Agent','summary':last_content or '模型未给出结论；请查看工具记录。',
                    'traces':tools.trace,'events':events,'model':model,'tool_count':steps,'model_calls':model_calls,
                    'elapsed_seconds':round(time.monotonic()-start,2),'usage':usage,
                    'limit_reached':steps>=max_steps,'quality':next((t['result'] for t in tools.trace if t['tool']=='data_quality'),None),
                    'limitations':['模型诊断未必正确；应与规则基线及测试真值核对。','指标贡献不是业务因果推断。']}
        # Remove internal thinking when passing history on (in case a reasoning model exposes it)
        assistant_msg={'role':'assistant','content':content,'tool_calls':calls}
        messages.append(assistant_msg)
        for call in calls:
            if steps >= max_steps:
                # Required: respond to every tool call so history remains valid.
                messages.append({'role':'tool','tool_name':call.get('function',{}).get('name','unknown'),
                                 'content':json.dumps({'error':'tool step budget exceeded'})})
                continue
            fn=call.get('function') or {}; name=fn.get('name','')
            try:
                params=_validate(name,_args(fn.get('arguments',{})))
                result=getattr(tools,name)(**params)
                ok=True
            except (ValueError,TypeError,AttributeError,KeyError,json.JSONDecodeError) as exc:
                params={}; result={'error':f'{type(exc).__name__}: {exc}'}; ok=False
            steps+=1
            events.append({'step':steps,'tool':name,'args':params,'ok':ok,'result':result})
            messages.append({'role':'tool','tool_name':name or 'unknown',
                             'content':json.dumps(result,ensure_ascii=False)[:18000]})
    raise AssertionError('unreachable')

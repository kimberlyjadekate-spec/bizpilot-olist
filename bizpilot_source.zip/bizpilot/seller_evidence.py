"""Read-only, parameterized SQLite evidence for Olist seller investigations."""
from contextlib import closing
from pathlib import Path
import sqlite3

MATCH = "category, month, origin, destination"
ROUND_TITLES = (
    "商家异常", "订单履约时间线", "严格同行匹配基准", "评分关联", "配送阶段与低评分",
)
MIN_ORDERS = 30
MIN_PEERS = 3
MIN_COVERAGE = 0.50


def connect(db):
    return sqlite3.connect(Path(db).resolve().as_uri() + "?mode=ro", uri=True)


def _dimension(table, key, fields):
    # Identical analytical projections can collapse. Conflicting keys are quarantined.
    return f"""SELECT {key}, {fields} FROM (
        SELECT DISTINCT {key}, {fields} FROM {table} WHERE {key} IS NOT NULL
    ) GROUP BY {key} HAVING COUNT(*) = 1"""


def _base(con):
    schema = {
        name: {row[1] for row in con.execute(f"PRAGMA table_info({name})")}
        for name in ("orders", "order_reviews", "products")
    }
    approvals = "order_approved_at"
    handoff = "order_delivered_carrier_date"
    optional = lambda table, col: col if col in schema[table] else f"NULL AS {col}"
    order_fields = ", ".join((
        "customer_id", "order_status", "order_purchase_timestamp",
        optional("orders", approvals), optional("orders", handoff),
        "order_delivered_customer_date", "order_estimated_delivery_date",
    ))
    review_fields = ", ".join(optional("order_reviews", col) for col in (
        "review_answer_timestamp", "review_creation_date", "review_id",
    ))
    products = (
        _dimension("products", "product_id", "product_category_name")
        if {"product_id", "product_category_name"} <= schema["products"]
        else "SELECT NULL AS product_id, NULL AS product_category_name WHERE 0"
    )
    return f"""WITH
    unique_orders AS MATERIALIZED ({_dimension("orders", "order_id", order_fields)}),
    unique_customers AS MATERIALIZED ({_dimension("customers", "customer_id", "customer_state")}),
    unique_sellers AS MATERIALIZED ({_dimension("sellers", "seller_id", "seller_state")}),
    unique_products AS MATERIALIZED ({products}),
    item_facts AS MATERIALIZED (
        SELECT DISTINCT order_id, order_item_id, seller_id, product_id FROM order_items
    ),
    exposures AS MATERIALIZED (
        SELECT order_id FROM item_facts WHERE seller_id = :seller_id GROUP BY order_id
    ),
    item_shape AS MATERIALIZED (
        SELECT i.order_id, COUNT(*) AS items,
               COUNT(*) - COUNT(DISTINCT i.order_item_id) AS conflicting_items,
               COUNT(DISTINCT i.seller_id) AS sellers, MIN(i.seller_id) AS seller_id,
               COUNT(*) - COUNT(NULLIF(TRIM(i.seller_id), '')) AS unknown_seller_items,
               COUNT(DISTINCT NULLIF(TRIM(p.product_category_name), '')) AS categories,
               MIN(NULLIF(TRIM(p.product_category_name), '')) AS category,
               COUNT(*) - COUNT(NULLIF(TRIM(p.product_category_name), '')) AS unknown_category_items
        FROM item_facts i LEFT JOIN unique_products p USING (product_id)
        GROUP BY i.order_id
    ),
    review_source AS (
        SELECT order_id, review_score, {review_fields} FROM order_reviews
    ),
    review_rank AS MATERIALIZED (
        SELECT order_id, CAST(review_score AS INTEGER) AS score,
               julianday(review_answer_timestamp) AS answered,
               ROW_NUMBER() OVER (
                  PARTITION BY order_id
                  ORDER BY julianday(review_answer_timestamp) DESC,
                           julianday(review_creation_date) DESC, review_id DESC,
                           CAST(review_score AS INTEGER) ASC
               ) AS rn
        FROM review_source
        WHERE TRIM(CAST(review_score AS TEXT)) IN ('1','2','3','4','5','1.0','2.0','3.0','4.0','5.0')
    ),
    order_join AS (
        SELECT i.*, o.order_id AS order_present, o.order_status AS status,
               DATE(o.order_purchase_timestamp) AS purchase_date,
               STRFTIME('%Y-%m', o.order_purchase_timestamp) AS month,
               NULLIF(TRIM(s.seller_state), '') AS origin,
               NULLIF(TRIM(c.customer_state), '') AS destination,
               r.score, r.answered, o.order_purchase_timestamp AS purchased,
               o.order_delivered_customer_date AS delivered,
               o.order_estimated_delivery_date AS promised,
               julianday(o.order_approved_at) - julianday(o.order_purchase_timestamp) AS approval_days,
               julianday(o.order_delivered_carrier_date) - julianday(o.order_approved_at) AS pre_days,
               julianday(o.order_delivered_customer_date) - julianday(o.order_delivered_carrier_date) AS transit_days,
               julianday(o.order_delivered_customer_date) - julianday(o.order_purchase_timestamp) AS total_days
        FROM item_shape i LEFT JOIN unique_orders o USING (order_id)
        LEFT JOIN unique_sellers s ON i.seller_id = s.seller_id
        LEFT JOIN unique_customers c ON o.customer_id = c.customer_id
        LEFT JOIN review_rank r ON i.order_id = r.order_id AND r.rn = 1
    ),
    facts AS MATERIALIZED (
        SELECT *,
               CASE WHEN status = 'delivered' AND DATE(delivered) IS NOT NULL
                    AND DATE(promised) IS NOT NULL THEN DATE(delivered) > DATE(promised) END AS late,
               CASE WHEN status = 'delivered' AND DATE(delivered) IS NOT NULL
                    AND DATE(promised) IS NOT NULL THEN julianday(delivered) > julianday(promised) END AS legacy_late,
               CASE WHEN status = 'delivered' THEN
                    approval_days >= 0 AND pre_days >= 0 AND transit_days >= 0 END AS valid_timeline,
               CASE WHEN score IS NOT NULL THEN answered >= julianday(delivered) END AS after_delivery,
               sellers = 1 AND unknown_seller_items = 0 AND conflicting_items = 0 AS sole_seller,
               categories = 1 AND unknown_category_items = 0 AS sole_category
        FROM order_join
    ),
    target AS MATERIALIZED (SELECT f.* FROM facts f JOIN exposures e USING (order_id)),
    strict AS MATERIALIZED (
        SELECT * FROM facts WHERE sole_seller AND sole_category AND late IS NOT NULL
          AND month IS NOT NULL AND origin IS NOT NULL AND destination IS NOT NULL
    )
"""


AUDIT = """
SELECT COUNT(*) AS exposure_orders, COUNT(DISTINCT order_id) AS unique_orders,
       MIN(purchase_date) AS first_purchase, MAX(purchase_date) AS last_purchase,
       (SELECT COUNT(*) FROM order_items JOIN exposures USING (order_id)) AS raw_item_rows,
       COALESCE(SUM(items), 0) AS distinct_item_rows,
       COUNT(CASE WHEN conflicting_items > 0 THEN 1 END) AS conflicting_item_orders,
       COUNT(CASE WHEN order_present IS NULL THEN 1 END) AS missing_or_conflicting_order,
       COUNT(CASE WHEN sellers > 1 THEN 1 END) AS multi_seller_orders,
       COUNT(CASE WHEN unknown_seller_items > 0 THEN 1 END) AS unknown_seller_orders,
       COUNT(CASE WHEN categories > 1 THEN 1 END) AS multi_category_orders,
       COUNT(CASE WHEN unknown_category_items > 0 THEN 1 END) AS unknown_category_orders,
       COUNT(CASE WHEN month IS NULL OR origin IS NULL OR destination IS NULL THEN 1 END) AS incomplete_match_keys,
       COUNT(CASE WHEN status = 'delivered' THEN 1 END) AS delivered_orders,
       COUNT(CASE WHEN status = 'delivered' AND late IS NULL THEN 1 END) AS missing_promise_dates,
       COUNT(late) AS valid_promise_orders,
       COUNT(CASE WHEN valid_timeline = 1 THEN 1 END) AS valid_timeline_orders,
       COUNT(CASE WHEN status = 'delivered' AND
            (approval_days IS NULL OR pre_days IS NULL OR transit_days IS NULL) THEN 1 END) AS missing_timeline,
       COUNT(CASE WHEN status = 'delivered' AND
            (approval_days < 0 OR pre_days < 0 OR transit_days < 0) THEN 1 END) AS inverted_timeline,
       COUNT(CASE WHEN sole_seller AND late IS NOT NULL THEN 1 END) AS sole_seller_promise_orders,
       COUNT(CASE WHEN sole_seller AND sole_category AND late IS NOT NULL THEN 1 END) AS sole_category_promise_orders,
       COUNT(CASE WHEN sole_seller AND sole_category AND late IS NOT NULL AND valid_timeline THEN 1 END) AS stage_review_orders,
       (SELECT COUNT(*) FROM strict WHERE seller_id = :seller_id) AS strict_orders,
       (SELECT COUNT(*) FROM review_source JOIN exposures USING (order_id)) AS raw_review_rows,
       (SELECT COUNT(*) FROM (
           SELECT DISTINCT r.* FROM review_source r JOIN exposures USING (order_id)
       )) AS distinct_review_projections,
       (SELECT COUNT(*) FROM (SELECT order_id FROM review_rank JOIN exposures USING (order_id)
           GROUP BY order_id HAVING COUNT(*) > 1)) AS multiple_valid_reviews,
       COUNT(score) AS reviewed_orders,
       COUNT(CASE WHEN after_delivery = 0 THEN 1 END) AS reviews_before_delivery,
       COUNT(CASE WHEN score IS NOT NULL AND answered IS NULL THEN 1 END) AS unknown_review_time
FROM target
"""

RISK = """
SELECT scope, COUNT(*) AS orders, COUNT(late) AS eligible, SUM(late) AS late_orders,
       AVG(late) AS late_rate, SUM(legacy_late) AS legacy_late_orders,
       AVG(legacy_late) AS legacy_late_rate
FROM (
    SELECT 'all_exposures' AS scope, * FROM target
    UNION ALL SELECT 'sole_seller', * FROM target WHERE sole_seller
    UNION ALL SELECT 'marketplace_reference', * FROM facts
) GROUP BY scope ORDER BY scope
"""

TIMELINE = """
, stage_values AS (
    SELECT late, 'purchase_to_approval' AS stage, approval_days AS days FROM target WHERE sole_seller AND valid_timeline
    UNION ALL SELECT late, 'approval_to_carrier', pre_days FROM target WHERE sole_seller AND valid_timeline
    UNION ALL SELECT late, 'carrier_to_delivery', transit_days FROM target WHERE sole_seller AND valid_timeline
    UNION ALL SELECT late, 'purchase_to_delivery', total_days FROM target WHERE sole_seller AND valid_timeline
),
ranked AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY stage, late ORDER BY days) AS rn,
              COUNT(*) OVER (PARTITION BY stage, late) AS n
    FROM stage_values
)
SELECT stage, late, COUNT(*) AS orders, AVG(days) AS mean_days,
       MIN(CASE WHEN 2 * rn >= n THEN days END) AS p50_days,
       MIN(CASE WHEN 10 * rn >= 9 * n THEN days END) AS p90_days
FROM ranked GROUP BY stage, late ORDER BY stage, late
"""

TIMELINE_COVERAGE = """
SELECT late, COUNT(*) AS orders,
       COUNT(CASE WHEN valid_timeline THEN 1 END) AS valid_timeline_orders,
       AVG(CASE WHEN valid_timeline THEN 1.0 ELSE 0.0 END) AS timeline_coverage,
       COUNT(CASE WHEN pre_days >= 0 THEN 1 END) AS usable_pre_stage,
       COUNT(CASE WHEN transit_days >= 0 THEN 1 END) AS usable_transit_stage
FROM target WHERE sole_seller AND status = 'delivered' GROUP BY late ORDER BY late
"""

REVIEW_COLUMNS = """
COUNT(*) AS orders, COUNT(score) AS reviewed,
COUNT(CASE WHEN score <= 2 THEN 1 END) AS low_reviews,
AVG(score) AS mean_score, AVG(score <= 2) AS low_rate,
1.0 * COUNT(score) / COUNT(*) AS review_coverage,
COUNT(CASE WHEN after_delivery = 1 THEN 1 END) AS post_delivery_reviewed,
COUNT(CASE WHEN after_delivery = 0 THEN 1 END) AS pre_delivery_reviewed,
COUNT(CASE WHEN score IS NOT NULL AND after_delivery IS NULL THEN 1 END) AS unknown_review_timing,
AVG(CASE WHEN after_delivery = 1 THEN score <= 2 END) AS post_delivery_low_rate
"""

REVIEW = f"""
SELECT scope, late, {REVIEW_COLUMNS}
FROM (
    SELECT 'sole_category' AS scope, * FROM target WHERE sole_seller AND sole_category AND late IS NOT NULL
    UNION ALL SELECT 'sole_seller', * FROM target WHERE sole_seller AND late IS NOT NULL
)
GROUP BY scope, late ORDER BY scope, late
"""


def _duration(field, thresholds):
    cut1, cut2, cut3 = thresholds
    return f"""CASE WHEN {field} < {cut1} THEN '[0,{cut1})'
               WHEN {field} < {cut2} THEN '[{cut1},{cut2})'
               WHEN {field} < {cut3} THEN '[{cut2},{cut3})'
               ELSE '{cut3}+' END"""


DELIVERY = f"""
SELECT stage, duration_days, late, {REVIEW_COLUMNS}
FROM (
    SELECT 'approval_to_carrier' AS stage, {_duration('pre_days', (1, 2, 4))} AS duration_days, *
    FROM target WHERE sole_seller AND sole_category AND valid_timeline AND late IS NOT NULL
    UNION ALL SELECT 'carrier_to_delivery', {_duration('transit_days', (3, 7, 14))}, *
    FROM target WHERE sole_seller AND sole_category AND valid_timeline AND late IS NOT NULL
    UNION ALL SELECT 'carrier_to_delivery_alternative', {_duration('transit_days', (2, 5, 10))}, *
    FROM target WHERE sole_seller AND sole_category AND valid_timeline AND late IS NOT NULL
)
GROUP BY stage, duration_days, late ORDER BY stage, MIN(transit_days), duration_days, late
"""

DELIVERY_CHECK = f"""
SELECT CASE WHEN transit_days >= 7 THEN 'long_7plus' ELSE 'short_under_7' END AS transit_group,
       late, {REVIEW_COLUMNS}
FROM target WHERE sole_seller AND sole_category AND valid_timeline AND late IS NOT NULL
GROUP BY transit_group, late ORDER BY transit_group, late
"""


def _benchmark(metrics):
    # Match each metric in its own eligible population. Strata are shared by order, not by item.
    pieces = [
        f"SELECT '{label}' AS metric, *, {value} AS measure FROM strict WHERE {condition}"
        for label, value, condition in metrics
    ]
    return f"""
, measures AS MATERIALIZED ({' UNION ALL '.join(pieces)}),
target_strata AS MATERIALIZED (
    SELECT metric, {MATCH}, COUNT(*) AS target_n, AVG(measure) AS target_mean
    FROM measures WHERE seller_id = :seller_id
    GROUP BY metric, {MATCH}
),
peer_rows AS MATERIALIZED (
    SELECT p.*, t.target_n, COUNT(*) OVER (PARTITION BY p.metric, {', '.join('p.' + key for key in MATCH.split(', '))}) AS peer_stratum_n
    FROM measures p JOIN target_strata t USING (metric, {MATCH})
    WHERE p.seller_id <> :seller_id
),
peer_strata AS MATERIALIZED (
    SELECT metric, {MATCH}, COUNT(*) AS peer_n, COUNT(DISTINCT seller_id) AS peer_sellers,
           AVG(measure) AS peer_mean
    FROM peer_rows GROUP BY metric, {MATCH}
),
strata AS MATERIALIZED (
    SELECT t.*, p.peer_n, p.peer_sellers, p.peer_mean
    FROM target_strata t LEFT JOIN peer_strata p USING (metric, {MATCH})
)
"""


BENCH_SUMMARY = f"""
, weighted_values AS (
    SELECT p.metric, 'peer' AS side, p.measure, SUM(1.0 * p.target_n / p.peer_stratum_n) AS weight
    FROM peer_rows p GROUP BY p.metric, p.measure
    UNION ALL
    SELECT m.metric, 'target', m.measure, COUNT(*)
    FROM measures m JOIN peer_strata p USING (metric, {MATCH})
    WHERE m.seller_id = :seller_id GROUP BY m.metric, m.measure
),
cdf AS (
    SELECT *, SUM(weight) OVER (PARTITION BY metric, side ORDER BY measure) AS running,
              SUM(weight) OVER (PARTITION BY metric, side) AS total
    FROM weighted_values
),
quantiles AS (
    SELECT metric,
           MIN(CASE WHEN side = 'target' AND running >= .5 * total - 1e-9 THEN measure END) AS target_p50,
           MIN(CASE WHEN side = 'target' AND running >= .9 * total - 1e-9 THEN measure END) AS target_p90,
           MIN(CASE WHEN side = 'peer' AND running >= .5 * total - 1e-9 THEN measure END) AS peer_p50,
           MIN(CASE WHEN side = 'peer' AND running >= .9 * total - 1e-9 THEN measure END) AS peer_p90
    FROM cdf GROUP BY metric
)
SELECT s.metric, SUM(target_n) AS target_orders, SUM(CASE WHEN peer_n IS NULL THEN target_n ELSE 0 END) AS unmatched_orders,
       COALESCE(SUM(CASE WHEN peer_n IS NOT NULL THEN target_n END), 0) AS matched_orders,
       COUNT(*) AS target_strata, COUNT(peer_n) AS matched_strata,
       COALESCE(SUM(peer_n), 0) AS peer_orders,
       (SELECT COUNT(DISTINCT seller_id) FROM peer_rows p WHERE p.metric = s.metric) AS peer_sellers,
       1.0 * SUM(CASE WHEN peer_n IS NOT NULL THEN target_n ELSE 0 END) / SUM(target_n) AS coverage,
       SUM(CASE WHEN peer_n IS NOT NULL THEN target_n * target_mean END) /
            SUM(CASE WHEN peer_n IS NOT NULL THEN target_n END) AS target_mean,
       SUM(target_n * peer_mean) / SUM(CASE WHEN peer_n IS NOT NULL THEN target_n END) AS peer_mean,
       SUM(CASE WHEN peer_sellers = 1 THEN target_n ELSE 0 END) AS matched_to_one_seller,
       q.target_p50, q.target_p90, q.peer_p50, q.peer_p90
FROM strata s LEFT JOIN quantiles q USING (metric) GROUP BY s.metric ORDER BY s.metric
"""

BENCH_STRATA = f"SELECT * FROM strata ORDER BY metric, {MATCH}"
FULFILLMENT = [
    ("late_rate", "late", "1"),
    ("pre_days", "pre_days", "valid_timeline"),
    ("transit_days", "transit_days", "valid_timeline"),
]
RATINGS = [
    ("low_on_time", "score <= 2", "score IS NOT NULL AND late = 0"),
    ("low_late", "score <= 2", "score IS NOT NULL AND late = 1"),
    ("low_on_time_post", "score <= 2", "after_delivery = 1 AND late = 0"),
    ("low_late_post", "score <= 2", "after_delivery = 1 AND late = 1"),
]


REVIEW_CONTRAST = f"""
, review_cohort AS MATERIALIZED (
    SELECT 'all_valid' AS scope, * FROM strict WHERE score IS NOT NULL AND (:timeline_only = 0 OR valid_timeline)
    UNION ALL SELECT 'post_delivery', * FROM strict WHERE after_delivery = 1 AND (:timeline_only = 0 OR valid_timeline)
),
cells AS MATERIALIZED (
    SELECT scope, {MATCH}, seller_id = :seller_id AS is_target, late,
           COUNT(*) AS n, AVG(score <= 2) AS low_rate
    FROM review_cohort GROUP BY scope, {MATCH}, is_target, late
),
common AS (
    SELECT scope, {MATCH}, SUM(CASE WHEN is_target THEN n ELSE 0 END) AS weight,
           SUM(CASE WHEN NOT is_target THEN n ELSE 0 END) AS peer_n,
           SUM(CASE WHEN is_target AND late = 0 THEN n ELSE 0 END) AS target_on_time,
           SUM(CASE WHEN is_target AND late = 1 THEN n ELSE 0 END) AS target_late,
           MAX(CASE WHEN is_target AND late = 1 THEN low_rate END) -
               MAX(CASE WHEN is_target AND late = 0 THEN low_rate END) AS target_gap,
           MAX(CASE WHEN NOT is_target AND late = 1 THEN low_rate END) -
               MAX(CASE WHEN NOT is_target AND late = 0 THEN low_rate END) AS peer_gap
    FROM cells GROUP BY scope, {MATCH} HAVING COUNT(*) = 4
),
total AS (
    SELECT scope, COUNT(*) AS target_reviewed FROM review_cohort WHERE seller_id = :seller_id GROUP BY scope
)
SELECT t.scope, t.target_reviewed, COUNT(c.scope) AS shared_strata,
       COALESCE(SUM(weight), 0) AS matched_orders, COALESCE(SUM(peer_n), 0) AS peer_orders,
       COALESCE(SUM(target_on_time), 0) AS target_on_time,
       COALESCE(SUM(target_late), 0) AS target_late,
       1.0 * COALESCE(SUM(weight), 0) / t.target_reviewed AS coverage,
       SUM(weight * target_gap) / SUM(weight) AS target_gap,
       SUM(weight * peer_gap) / SUM(weight) AS peer_gap,
       SUM(weight * (target_gap - peer_gap)) / SUM(weight) AS excess_gap
FROM total t LEFT JOIN common c USING (scope) GROUP BY t.scope ORDER BY t.scope
"""

FOCUSES = {
    1: {"baseline": "按计划调查"},
    2: {"baseline": "查看全量时间线", "route": "加查各收货州的阶段耗时"},
    3: {"baseline": "执行严格匹配", "category": "加查目标商家的品类结构"},
    4: {"baseline": "检查延迟与评分", "score_mix": "加查按时和延迟的完整评分分布"},
    5: {"baseline": "检查配送阶段与评分", "promise": "加查承诺窗口与评分"},
}

FOCUS_QUERIES = {
    "route": ("按收货州核查时间线",
              """SELECT destination, late, COUNT(*) AS orders, AVG(pre_days) AS pre_days,
                        AVG(transit_days) AS transit_days
                 FROM target WHERE sole_seller AND valid_timeline GROUP BY destination, late
                 ORDER BY destination, late"""),
    "category": ("按品类核查目标订单结构",
                 """SELECT category, COUNT(*) AS orders, AVG(late) AS late_rate
                    FROM target WHERE sole_seller AND sole_category AND late IS NOT NULL
                    GROUP BY category ORDER BY orders DESC, category"""),
    "score_mix": ("按承诺状态核查评分分布",
                  """SELECT late, score, COUNT(*) AS orders FROM target
                     WHERE sole_seller AND late IS NOT NULL GROUP BY late, score ORDER BY late, score"""),
    "promise": ("按下单至承诺日窗口核查评分", f"""
                 SELECT promise_window, late, {REVIEW_COLUMNS} FROM (
                     SELECT {_duration("julianday(DATE(promised)) - julianday(purchase_date)", (7, 14, 21))} AS promise_window, *
                     FROM target WHERE sole_seller AND sole_category AND valid_timeline AND late IS NOT NULL
                        AND DATE(promised) >= purchase_date
                 ) GROUP BY promise_window, late ORDER BY MIN(julianday(DATE(promised)) - julianday(purchase_date)), late"""),
}

def _queries(round_no):
    if round_no == 1:
        return [("risk", "延迟口径复算与平台背景", "按自然日比较实际与承诺日期。旧版时间戳口径单列。", RISK)]
    if round_no == 2:
        return [
            ("timeline", "履约阶段耗时", "单商家、完整且顺序有效的时间线。天数 P50/P90 为经验分位数。", TIMELINE),
            ("timeline_coverage", "时间线排除与样本覆盖", "按承诺状态核对交付订单的完整时间线覆盖。", TIMELINE_COVERAGE),
        ]
    if round_no == 4:
        extra = [("review", "承诺违约与低评分", "低评分为 1–2 分。单商家全品类作为敏感性对照。", REVIEW)]
    elif round_no == 5:
        extra = [
            ("delivery", "交接前后耗时分箱与评分", "完整时间线的单商家、单已知品类订单。按承诺状态分层。", DELIVERY),
            ("counter", "长配送仍按时的反证", "以 7 天区分长短。比较按时/超期及签收后回答的敏感性。", DELIVERY_CHECK),
        ]
    else:
        extra = []
    metrics = {
        3: FULFILLMENT,
        4: RATINGS,
        5: FULFILLMENT[1:] + [
            (label, value, f"({condition}) AND valid_timeline") for label, value, condition in RATINGS
        ],
    }[round_no]
    if round_no in (4, 5):
        extra.append(("contrast", "共同分层内的延迟评分差", "分层须同时包含目标和同行各自的按时与延迟评分。四组共用同一目标订单权重。", REVIEW_CONTRAST))
    prefix = _benchmark(metrics)
    return extra + [
        ("peer", "严格同行标准化汇总", "同行按目标分层样本量加权。无同行分层单列。", prefix + BENCH_SUMMARY),
        ("strata", "匹配分层明细", "品类 × 下单月份 × 商家所在州 × 收货州。同行排除目标商家。", prefix + BENCH_STRATA),
    ]


def collect(db, seller_id, round_no, focus="baseline"):
    if focus not in FOCUSES.get(round_no, {}):
        raise ValueError("调查轮次或加查方向无效。")
    params = {"seller_id": seller_id}
    if round_no in (4, 5):
        params["timeline_only"] = int(round_no == 5)
    evidence = {}
    with closing(connect(db)) as con:
        con.row_factory = sqlite3.Row
        con.execute("BEGIN")
        base = _base(con)
        queries = [
            ("audit", "数据粒度与覆盖审计", "目标商家的订单暴露，每单一行。排除原因可重叠。", AUDIT),
            *_queries(round_no),
        ]
        if focus != "baseline":
            title, body = FOCUS_QUERIES[focus]
            queries.append(("focus", title, "用户确认的加查方向。", body))
        for key, title, scope, body in queries:
            sql = base + body
            rows = [dict(row) for row in con.execute(sql, params)]
            evidence[key] = {"id": f"R{round_no:02}-{key}", "title": title, "scope": scope,
                             "sql": sql, "params": params, "rows": rows}
            if key == "audit":
                row = rows[0]
                if not row["exposure_orders"]:
                    raise ValueError("订单商品表中找不到该 seller_id。")
                if row["exposure_orders"] != row["unique_orders"]:
                    raise ValueError("订单粒度审计失败，已停止生成结论。")
    return evidence

"""A presentation of the saved measurements and revisions for any seller case."""
import pandas as pd
import streamlit as st

from .seller_agent import HYPOTHESES


def _find(evidence, key, **match):
    return next((row for row in evidence.get(key, {}).get("rows", [])
                 if all(row.get(column) == value for column, value in match.items())), {})


def _percent(value):
    return f"{value:.2%}" if value is not None else "证据不足"


def _gap(value, baseline, scale, unit):
    if value is None or baseline is None:
        return "证据不足"
    return f"{(value - baseline) * scale:+.2f} {unit}"


def _number(value):
    return f"{value:,}" if value is not None else "—"


def _ratio(numerator, denominator):
    return f"{_number(numerator)} / {_number(denominator)}"


def show_sql(item):
    st.code(item["sql"], language="sql")
    st.json(item["params"])


def _proof(evidence, key, label, rows, captions=()):
    item = evidence.get(key)
    if not item:
        return
    with st.expander(f"{label} · {item['id']}"):
        st.caption(item["scope"])
        for caption in captions:
            st.caption(caption)
        if rows:
            st.dataframe(pd.DataFrame(rows), hide_index=True)
        else:
            st.info("此口径没有符合条件的结果。")
        st.markdown("**SQL 与绑定参数**")
        show_sql(item)


def _review_comparison(label, group):
    return {
        "订单组": label,
        "低评分 / 有效评价": _ratio(group.get("low_reviews"), group.get("reviewed")),
        "低评分率": _percent(group.get("low_rate")),
        "签收后评价数": _number(group.get("post_delivery_reviewed")),
        "签收后低评分率": _percent(group.get("post_delivery_low_rate")),
    }


def render_case_overview(case):
    """Render only the measurements already saved in this case."""
    by_round = {row["round"]: row for row in case["rounds"]}
    evidence = {number: row["evidence"] for number, row in by_round.items()}
    st.caption(f"商家 {case['seller_id']}　·　{len(by_round)} / 5 轮")
    if not evidence:
        st.info("完成第一轮后，这里会显示调查总览。")
        return

    risk = _find(evidence.get(1, {}), "risk", scope="all_exposures")
    peers = evidence.get(3, {})
    late = _find(peers, "peer", metric="late_rate")
    pre = _find(peers, "peer", metric="pre_days")
    transit = _find(peers, "peer", metric="transit_days")

    first, second, third = st.columns(3)
    first.metric("承诺自然日延迟率", _percent(risk.get("late_rate")), border=True)
    second.metric("严格匹配延迟率差", _gap(late.get("target_mean"), late.get("peer_mean"), 100, "个百分点"), border=True)
    third.metric("交接后平均耗时差", _gap(transit.get("target_mean"), transit.get("peer_mean"), 1, "天"), border=True)

    st.markdown("### 01　发现异常")
    if risk:
        st.write(f"按承诺自然日，{_number(risk.get('eligible'))} 笔有效订单中，"
                 f"{_number(risk.get('late_orders'))} 笔延迟。先核对两种口径，再用可比同行判断风险。")
    _proof(evidence.get(1, {}), "risk", "查看有效订单与两种延迟口径", [{
        "订单暴露": _number(risk.get("orders")),
        "自然日延迟 / 有效": _ratio(risk.get("late_orders"), risk.get("eligible")),
        "自然日延迟率": _percent(risk.get("late_rate")),
        "旧版延迟 / 有效": _ratio(risk.get("legacy_late_orders"), risk.get("eligible")),
        "旧版延迟率": _percent(risk.get("legacy_late_rate")),
    }] if risk else [])

    st.markdown("### 02　用同行定位履约阶段")
    if late and late.get("matched_orders"):
        st.write(f"目标的匹配队列延迟率为 **{_percent(late['target_mean'])}**，标准化同行为 "
                 f"**{_percent(late['peer_mean'])}**。匹配覆盖 **{_percent(late['coverage'])}**，"
                 f"涉及 {_number(late['peer_sellers'])} 家同行。")
    else:
        st.caption("完成严格匹配后显示可比结果。缺少可比分层时，同行基准为空。")
    if pre.get("target_mean") is not None and transit.get("target_mean") is not None:
        before = _gap(pre["target_mean"], pre["peer_mean"], 1, "天")
        after = _gap(transit["target_mean"], transit["peer_mean"], 1, "天")
        st.write(f"目标减同行的平均耗时，交接前 **{before}**，交接后 **{after}**。")
    timeline = evidence.get(2, {})
    _proof(timeline, "timeline", "查看按时和延迟的阶段时间线", [
        {"阶段": {"purchase_to_approval": "下单到批准", "approval_to_carrier": "批准到交接",
                  "carrier_to_delivery": "交接到签收", "purchase_to_delivery": "下单到签收"}.get(row["stage"], row["stage"]),
         "承诺状态": {0: "按时", 1: "延迟"}.get(row["late"], "日期未知"),
         "订单数": row["orders"], "中位耗时（天）": round(row["p50_days"], 2),
         "P90 耗时（天）": round(row["p90_days"], 2)}
        for row in timeline.get("timeline", {}).get("rows", [])
    ])
    _proof(peers, "peer", "查看匹配覆盖、加权基准与分母", [
        {"指标": label, "目标匹配 / 合格": _ratio(row["matched_orders"], row["target_orders"]),
         "同行订单": row["peer_orders"], "同行商家": row["peer_sellers"],
         "目标值": format_value(row["target_mean"]), "同行值": format_value(row["peer_mean"])}
        for label, row, format_value in (
            ("延迟率", late, _percent),
            ("交接前均值（天）", pre, lambda value: f"{value:.2f}" if value is not None else "—"),
            ("交接后均值（天）", transit, lambda value: f"{value:.2f}" if value is not None else "—"),
        ) if row
    ], ("严格匹配使用品类、下单月份、商家所在州、收货州。同行排除目标商家，按目标订单的分层分布加权。",))

    st.markdown("### 03　用反证核对低评分")
    review = evidence.get(4, {})
    delivery = evidence.get(5, {})
    short = _find(delivery, "counter", late=0, transit_group="short_under_7")
    long = _find(delivery, "counter", late=0, transit_group="long_7plus")
    post = _find(delivery, "contrast", scope="post_delivery")
    if short and long:
        st.write(f"只比较按时订单，配送至少 7 天的低评分率为 **{_percent(long['low_rate'])}**，"
                 f"短于 7 天为 **{_percent(short['low_rate'])}**。"
                 "再限定评价时点，检查关联是否仍然成立。")
    else:
        st.caption("完成评分和配送阶段分析后，在这里检查按时长配送及签收后评价。")
    _proof(review, "review", "查看延迟评分差与评价时点", [
        _review_comparison(label, group) for label, group in (
            ("按时", _find(review, "review", scope="sole_category", late=0)),
            ("延迟", _find(review, "review", scope="sole_category", late=1)),
        ) if group
    ])
    _proof(delivery, "counter", "查看按时长短配送的反证与分母", [
        _review_comparison(label, group)
        for label, group in (("按时 · 短于 7 天", short), ("按时 · 至少 7 天", long),
                             ("延迟 · 至少 7 天", _find(delivery, "counter", late=1, transit_group="long_7plus")))
        if group
    ])
    _proof(delivery, "contrast", "查看签收后评价的共同分层", [{
        "目标评价落入共同分层 / 合格评价": _ratio(post.get("matched_orders"), post.get("target_reviewed")),
        "覆盖率": _percent(post.get("coverage")), "共同分层": post.get("shared_strata"),
        "匹配目标延迟评价": post.get("target_late"),
    }] if post else [], ("共同分层需同时具备目标和同行各自的按时、延迟评价。",))

    st.markdown("### 04　修订判断")
    for number, keys in ((3, {"seller", "stage"}), (5, {"duration", "ratings", "excess"})):
        for change in by_round.get(number, {}).get("changes", []):
            if change["hypothesis"] in keys:
                st.markdown(f"**{HYPOTHESES[change['hypothesis']]}**　·　{change['before']} → **{change['after']}**")
                st.caption(change["explanation"])
                refs = list(dict.fromkeys(change["support"] + change["counter"]))
                if refs:
                    st.caption("证据 " + "、".join(refs))
    st.caption("Olist 订单时间戳用于定位履约阶段。进一步核验具体原因需要可关联的承运数据，例如线路与承运商编号、扫描时间和异常签收记录。")


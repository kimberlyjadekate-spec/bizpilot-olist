"""Resolve Olist inputs and show which project and data store are in use."""
from contextlib import closing
from pathlib import Path
import sqlite3

import streamlit as st

from .olist_adapter import OPTIONAL, REQUIRED


def csv_inventory(folder):
    return {name: (folder / name).is_file() for name in (*REQUIRED, *OPTIONAL)}


def default_csv_folder(data_dir, alternatives):
    local = data_dir / "olist_raw"
    if any(csv_inventory(local).values()):
        return local
    for folder in alternatives:
        if all(csv_inventory(folder).values()):
            return folder
    return local


def _database_status(db, kind):
    if not db.is_file():
        return "尚未导入" if kind == "orders" else "0 份"
    try:
        with closing(sqlite3.connect(db.resolve().as_uri() + "?mode=ro", uri=True)) as con:
            if kind == "orders":
                tables = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
                required = {name.removeprefix("olist_").removesuffix("_dataset.csv") for name in REQUIRED}
                if not required <= tables:
                    return "缺少 Olist 数据表"
                return "已就绪（含商品表）" if "products" in tables else "已就绪（缺商品表）"
            count = con.execute("SELECT COUNT(*) FROM seller_cases").fetchone()[0]
            return f"{count} 份"
    except (OSError, sqlite3.Error):
        return "读取失败"


def show_data_status(root, csv_folder, db, store, inventory):
    present = sum(inventory.values())
    orders_status = _database_status(db, "orders")
    ready = orders_status.startswith("已就绪")
    st.markdown(f"**原始 CSV**　{present}/{len(inventory)} 张　 · 　"
                f"**Olist 数据库**　{orders_status}　 · 　"
                f"**调查记录**　{_database_status(store, 'cases')}")
    with st.expander("当前项目与数据位置", expanded=not ready):
        st.text(f"项目      {root}\nCSV       {csv_folder}\n订单数据库  {db}\n调查历史   {store}")
        missing = [name for name in REQUIRED if not inventory[name]]
        if missing:
            st.caption("当前 CSV 目录缺少 " + "、".join(missing))
        elif not all(inventory.values()):
            st.caption("五张必需表齐全。补充商品表可启用严格品类匹配。")
    return ready

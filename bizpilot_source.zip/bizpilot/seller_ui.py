"""Streamlit integration for the Olist workspace."""
import json
import sqlite3

import pandas as pd
import streamlit as st

from .seller_agent import (
    HYPOTHESES, REASONS, REFERENCE_SELLER, cases, new_case, reflect, run_round,
)
from .seller_evidence import FOCUSES, ROUND_TITLES
from .seller_overview import render_case_overview, show_sql

RATE_COLUMNS = {
    "late_rate", "legacy_late_rate", "low_rate", "review_coverage", "post_delivery_low_rate",
    "coverage", "timeline_coverage", "target_gap", "peer_gap", "excess_gap",
}
PAGES = {
    "audit": "数据质量", "risk": "延迟概览", "timeline": "阶段耗时", "timeline_coverage": "时间线覆盖",
    "peer": "同行汇总", "strata": "分层明细", "review": "评分关联", "delivery": "配送阶段",
    "counter": "反证", "contrast": "共同分层", "focus": "加查",
}
RATING_METRICS = {"late_rate", "low_on_time", "low_late", "low_on_time_post", "low_late_post"}


def _table(item):
    frame = pd.DataFrame(item["rows"])
    if frame.empty:
        st.info("此口径没有符合条件的订单。")
        return
    if "late" in frame:
        frame["late"] = frame["late"].map({0: "按时", 1: "延迟"}).fillna("承诺未知")
    columns = {}
    for name in RATE_COLUMNS.intersection(frame.columns):
        frame[name] *= 100
        columns[name] = st.column_config.NumberColumn(f"{name} (%)", format="%.2f")
    if item["id"].endswith("-peer"):
        rate_mask = frame["metric"].isin(RATING_METRICS)
        for side in ("target", "peer"):
            frame[f"{side}_value_pct"] = frame[f"{side}_mean"].where(rate_mask) * 100
            frame[f"{side}_mean_days"] = frame[f"{side}_mean"].where(~rate_mask)
            frame = frame.drop(columns=f"{side}_mean")
            for percentile in ("p50", "p90"):
                frame[f"{side}_{percentile}"] = frame[f"{side}_{percentile}"].where(~rate_mask)
        st.caption("比例指标以百分比显示。耗时以天显示。分位数列仅用于耗时。")
    st.dataframe(frame, hide_index=True)


def _evidence(item):
    st.markdown(f"#### {item['title']}")
    st.caption(f"{item['id']} · {item['scope']}")
    if item["id"] == "R05-delivery" and item["rows"]:
        chart = pd.DataFrame(item["rows"])
        stage = st.radio("配送阶段", list(chart["stage"].unique()), horizontal=True,
                         format_func={
                             "approval_to_carrier": "交接前", "carrier_to_delivery": "交接后",
                             "carrier_to_delivery_alternative": "交接后（替代分箱）",
                         }.get)
        chart = chart[chart["stage"] == stage].copy()
        chart["承诺状态"] = chart["late"].map({0: "按时", 1: "延迟"})
        chart["低评分率 (%)"] = chart["low_rate"] * 100
        chart["区间下界"] = chart["duration_days"].str.extract(r"(\d+)").astype(int)
        chart = chart.sort_values("区间下界")
        if chart["low_rate"].notna().any():
            st.bar_chart(chart, x="duration_days", y="低评分率 (%)", color="承诺状态",
                         stack=False, sort=False)
        st.caption("下表保留分母与评价时点。小样本分箱仅供描述。")
    _table(item)
    with st.expander("查看 SQL 与绑定参数"):
        show_sql(item)
        st.caption("将查询和参数传给 SQLite 执行。导出的 JSON 保留原始比例与完整结果。")


def _round_view(row):
    for change in row["changes"]:
        st.markdown(f"**{HYPOTHESES[change['hypothesis']]}**")
        st.markdown(f"{change['before']} → **{change['after']}**")
        st.write(change["explanation"])
        citations = []
        if change["support"]:
            citations.append("支持 " + "、".join(change["support"]))
        if change["counter"]:
            citations.append("反证或限制 " + "、".join(change["counter"]))
        if citations:
            st.caption("　·　".join(citations))
    result = row["reflection"]
    reason = REASONS[result["reason"]]
    st.markdown(f"**下一步建议**　{reason} · {', '.join(result['evidence_ids'])}")
    if result["mode"] == "fallback":
        st.warning(f"Ollama 本轮降级到规则判断，SQL 证据已保存。{result.get('detail', '')}")
    elif result["mode"] == "ollama":
        st.caption(f"由本地 {result['model']} 选择加查方向，判断与指标由 SQL 和规则生成。")
    else:
        st.caption("使用 SQL 与规则生成判断。")
    selected = FOCUSES[row["round"]][row["selection"]["focus"]]
    st.caption(f"用户已确认 · {selected}")
    evidence = row["evidence"]
    tabs = st.tabs([PAGES[key] for key in evidence])
    for tab, item in zip(tabs, evidence.values()):
        with tab:
            _evidence(item)


def seller_workspace(db, store, model):
    st.markdown("### Seller Investigation Agent")
    st.caption("五轮真实订单调查 · 历史调查与原始 SQL 保存在本机 · 低评分为 1–2 分")
    st.caption("严格匹配按品类、下单月份、商家所在州和收货州，排除目标商家。"
               "描述性判断使用至少 30 笔/组、50% 匹配覆盖、同行汇总至少 3 家。")
    if db.is_file():
        with st.form("seller_new_case"):
            seller_id = st.text_input("seller_id", value=REFERENCE_SELLER, key="olist_seller_id")
            create = st.form_submit_button("新建商家调查", type="primary")
        if create:
            try:
                case = new_case(store, db, seller_id)
                st.session_state["seller_active_case"] = case["investigation_id"]
                st.session_state.pop("seller_case_selector", None)
            except (sqlite3.Error, OSError, ValueError) as exc:
                st.error(str(exc))
    else:
        st.info("先导入 Olist CSV，历史调查仍可查看。")
    try:
        history = cases(store) if store.is_file() else []
    except (sqlite3.Error, OSError, ValueError) as exc:
        st.error(f"无法读取调查历史。{exc}")
        return
    if not history:
        st.info("当前工作区暂无调查记录。已有记录可在存放调查数据库的工作区打开。")
        return
    lookup = {case["investigation_id"]: case for case in history}
    options = list(lookup)
    active = st.session_state.get("seller_active_case")
    case_id = st.selectbox(
        "打开本地调查", options, index=options.index(active) if active in options else 0,
        format_func=lambda key: f"{lookup[key]['seller_id']} · {len(lookup[key]['rounds'])}/5 · {key[:8]}",
        key="seller_case_selector",
    )
    case = lookup[case_id]
    completed = len(case["rounds"])
    st.progress(completed / len(ROUND_TITLES), text=f"已完成 {completed} / {len(ROUND_TITLES)} 轮")
    if case["historical_reference"]:
        st.caption("前序对话参考 · 195 笔，约 11.0%。第一轮独立复算旧版和自然日两个口径。")
    if completed:
        latest = case["rounds"][-1]
        if latest["evidence"]["audit"]["rows"][0]["unknown_category_orders"]:
            st.caption("含未知品类的订单已从单一已知品类队列排除。请在数据质量中核对排除量，必要时补充 products CSV 后重新导入。")
        views = ["调查总览", "逐轮证据"]
        view = st.radio("调查视图", views, index=0 if completed == len(ROUND_TITLES) else 1, horizontal=True,
                        key=f"seller_view_{case_id}")
        if view == views[0]:
            render_case_overview(case)
        else:
            selected = st.selectbox("查看已完成轮次", range(1, completed + 1), index=completed - 1,
                                    format_func=lambda n: f"R{n:02} · {ROUND_TITLES[n - 1]}",
                                    key=f"seller_round_view_{case_id}_{completed}")
            _round_view(case["rounds"][selected - 1])
        st.download_button("导出调查、判断修订和 SQL（JSON）",
                           json.dumps(case, ensure_ascii=False, indent=2, allow_nan=False),
                           f"bizpilot_seller_{case_id[:8]}.json", "application/json")
        if st.button("用本地模型复核最新轮", key="seller_retry_model"):
            try:
                with st.spinner("正在复核下一步调查方向…"):
                    reflect(store, case_id, completed, model=model)
                st.rerun()
            except (sqlite3.Error, OSError, ValueError) as exc:
                st.error(str(exc))
    if completed == len(ROUND_TITLES):
        st.success("五轮调查已完成。")
        return
    if not db.is_file():
        return
    number = completed + 1
    choices = list(FOCUSES[number])
    recommendation = case["rounds"][-1]["reflection"]["next_focus"] if completed else "baseline"
    with st.form(f"seller_next_{case_id}_{number}"):
        focus = st.radio("本轮调查方向", choices, index=choices.index(recommendation) if recommendation in choices else 0,
                         format_func=FOCUSES[number].get, horizontal=True)
        use_model = st.checkbox("使用 Ollama 复核下一步方向", value=True, key="seller_use_model")
        execute = st.form_submit_button(f"确认 R{number:02} · {ROUND_TITLES[number - 1]}", type="primary")
    if execute:
        try:
            with st.spinner("正在查询 Olist 并保存证据…"):
                run_round(store, db, case_id, number, focus)
            if use_model:
                with st.spinner("SQL 证据已保存，等待 Ollama 复核…"):
                    reflect(store, case_id, number, model=model)
            st.rerun()
        except (sqlite3.Error, OSError, ValueError) as exc:
            st.error(str(exc))


@st.cache_data(show_spinner=False)
def _public_case(path):
    return json.loads(path.read_text(encoding="utf-8"))


def public_seller_workspace(path):
    st.markdown("### Seller Investigation Agent")
    st.caption("公开只读案例 · Olist 真实历史订单 · 低评分为 1–2 分")
    case = _public_case(path)
    view = st.radio("调查视图", ["调查总览", "逐轮证据"], horizontal=True)
    if view == "调查总览":
        render_case_overview(case)
    else:
        rounds = case["rounds"]
        selected = st.selectbox("查看已完成轮次", range(len(rounds)),
                                format_func=lambda i: f"R{i + 1:02} · {ROUND_TITLES[i]}")
        _round_view(rounds[selected])
    st.download_button("导出五轮证据和 SQL（JSON）", path.read_bytes(),
                       "olist_seller_verified.json", "application/json")
    st.caption("数据来源：[Olist Brazilian E-Commerce Public Dataset](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce)")

"""Persistent five-round workflow. SQL determines assessments; Ollama prioritizes follow-up."""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
from uuid import uuid4

from .local_agent import DEFAULT_MODEL, DEFAULT_URL, LocalAgentError, _request
from .seller_evidence import (
    FOCUSES, MIN_COVERAGE, MIN_ORDERS, MIN_PEERS, ROUND_TITLES, collect, connect,
)

REFERENCE_SELLER = "4a3ca9315b744ce9f8e9374361493884"
HYPOTHESES = {
    "seller": "目标商家的延迟风险高于可比同行",
    "stage": "交接前或交接后的耗时差异值得优先调查",
    "ratings": "超过承诺日期的订单更常出现低评分",
    "duration": "配送耗时越长，低评分风险越高",
    "excess": "目标商家的延迟与低评分关联强于严格同行",
}
REASONS = {
    "volume": "核查订单规模与覆盖",
    "routes": "核查配送地区差异",
    "composition": "核查商品组合差异",
    "ratings": "核查评分分布和评价时点",
    "promise": "核查承诺窗口的影响",
    "complete": "汇总已核验的证据与限制",
}
FOCUS_REASONS = {"route": "routes", "category": "composition", "score_mix": "ratings", "promise": "promise"}


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _stamp(db):
    info = Path(db).stat()
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)


def snapshot(db):
    stamp = _stamp(db)
    with Path(db).open("rb") as source:
        digest = hashlib.file_digest(source, "sha256").hexdigest()
    if stamp != _stamp(db):
        raise ValueError("Olist 正在重新导入，请稍后重试。")
    return digest, stamp


def _store(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, timeout=10)
    try:
        con.execute("""CREATE TABLE IF NOT EXISTS seller_cases (
            id TEXT PRIMARY KEY, revision INTEGER NOT NULL, payload TEXT NOT NULL)""")
    except sqlite3.Error:
        con.close()
        raise
    return con


def cases(store):
    with closing(_store(store)) as con:
        return [json.loads(row[0]) for row in con.execute(
            "SELECT payload FROM seller_cases ORDER BY rowid DESC"
        )]


def load_case(store, case_id):
    with closing(_store(store)) as con:
        row = con.execute("SELECT payload FROM seller_cases WHERE id = ?", (case_id,)).fetchone()
    if row is None:
        raise ValueError("调查记录不存在。")
    return json.loads(row[0])


def _serialize(case):
    return json.dumps(case, ensure_ascii=False, allow_nan=False)


def new_case(store, db, seller_id):
    seller_id = seller_id.strip()
    if not seller_id:
        raise ValueError("请输入 seller_id。")
    digest, stamp = snapshot(db)
    with closing(connect(db)) as con:
        found = con.execute("SELECT 1 FROM order_items WHERE seller_id = ? LIMIT 1", (seller_id,)).fetchone()
    if stamp != _stamp(db):
        raise ValueError("Olist 数据已更新，请重试。")
    if not found:
        raise ValueError("订单商品表中找不到该 seller_id。")
    case = {
        "investigation_id": uuid4().hex, "seller_id": seller_id, "created_at": _now(),
        "schema_version": 1, "revision": 0, "source_sha256": digest, "rounds": [],
        "matching": ["category", "purchase_month", "seller_state", "customer_state"],
        "hypotheses": HYPOTHESES,
        "historical_reference": (
            {"late_orders": 195, "late_rate_approx": 0.11, "status": "前序对话参考，须由 R01 独立复算"}
            if seller_id == REFERENCE_SELLER else None
        ),
        "assessment_policy": {
            "min_orders_per_comparison_group": MIN_ORDERS, "min_peer_sellers": MIN_PEERS,
            "min_coverage": MIN_COVERAGE, "late_gap_pp": 2, "rating_gap_pp": 5,
            "stage_gap_days": 0.5, "interpretation": "描述性筛查门槛，未作显著性或因果检验",
        },
    }
    with closing(_store(store)) as con, con:
        con.execute("INSERT INTO seller_cases VALUES (?, 0, ?)", (case["investigation_id"], _serialize(case)))
    return case


def _save(store, case):
    expected = case["revision"]
    case["revision"] += 1
    with closing(_store(store)) as con, con:
        updated = con.execute(
            "UPDATE seller_cases SET revision = ?, payload = ? WHERE id = ? AND revision = ?",
            (case["revision"], _serialize(case), case["investigation_id"], expected),
        )
        if updated.rowcount != 1:
            raise ValueError("调查已在另一窗口更新，请刷新后继续。")
    return case


def _enough_peer(row):
    return (row and row["matched_orders"] >= MIN_ORDERS and row["peer_orders"] >= MIN_ORDERS
            and row["peer_sellers"] >= MIN_PEERS and row["coverage"] >= MIN_COVERAGE)


def _gap(rows, count="reviewed", rate="low_rate"):
    if set(rows) != {0, 1} or any(row[count] < MIN_ORDERS for row in rows.values()):
        return None
    return rows[1][rate] - rows[0][rate]


def assess(round_no, evidence, previous):
    judgments = dict(previous)
    changes = []

    def record(hypothesis, state, explanation, support=(), counter=()):
        before = judgments.get(hypothesis, "待检验")
        judgments[hypothesis] = state
        changes.append({
            "hypothesis": hypothesis, "before": before, "after": state,
            "explanation": explanation,
            "support": [evidence[key]["id"] for key in support],
            "counter": [evidence[key]["id"] for key in counter],
        })

    if round_no == 1:
        row = next(row for row in evidence["risk"]["rows"] if row["scope"] == "all_exposures")
        if row["eligible"]:
            record("seller", "待严格同行核验",
                   f"自然日口径 {row['late_orders']}/{row['eligible']}（{row['late_rate']:.1%}）。"
                   f"旧版时间戳口径 {row['legacy_late_orders']}/{row['eligible']}。"
                   "订单暴露含多商家订单，平台背景用于筛查。", ("risk",), ("audit",))
        else:
            record("seller", "证据不足", "缺少可比较的实际和承诺日期。", counter=("audit",))
    elif round_no == 2:
        rows = {(r["stage"], r["late"]): r for r in evidence["timeline"]["rows"]}
        shifts = {}
        for stage in ("approval_to_carrier", "carrier_to_delivery"):
            on_time, late = rows.get((stage, 0)), rows.get((stage, 1))
            if on_time and late and min(on_time["orders"], late["orders"]) >= MIN_ORDERS:
                shifts[stage] = late["p50_days"] - on_time["p50_days"]
        if shifts:
            stage = max(shifts, key=shifts.get)
            label = "交接前" if stage == "approval_to_carrier" else "交接后"
            record("stage", "待同行核验",
                   f"延迟组与按时组的中位数差以{label}最大（{shifts[stage]:+.2f} 天）。"
                   "同行比较还需控制月份、地区和品类。", ("timeline",), ("timeline_coverage",))
        else:
            record("stage", "证据不足", "完整时间线中至少一组样本不足。", counter=("timeline_coverage",))
    elif round_no == 3:
        peers = {row["metric"]: row for row in evidence["peer"]["rows"]}
        row = peers.get("late_rate")
        if _enough_peer(row):
            gap = row["target_mean"] - row["peer_mean"]
            elevated = gap >= 0.02
            record("seller", "上调商家核查优先级" if elevated else "下调商家核查优先级",
                   f"可匹配目标订单的延迟率较标准化同行 {gap * 100:+.2f} 个百分点，"
                   f"严格队列覆盖 {row['coverage']:.1%}。筛查门槛为高出 2 个百分点。",
                   ("peer",) if elevated else (), ("strata",) if elevated else ("peer", "strata"))
        else:
            record("seller", "证据不足", "严格同行的样本量或覆盖未达到筛查门槛。", counter=("peer", "audit"))
        stages = [(label, peers[key]["target_mean"] - peers[key]["peer_mean"])
                  for key, label in (("pre_days", "交接前"), ("transit_days", "交接后"))
                  if _enough_peer(peers.get(key))]
        if stages:
            label, gap = max(stages, key=lambda pair: pair[1])
            record("stage", f"优先核查{label}" if gap >= 0.5 else "下调阶段异常判断",
                   f"通过样本门槛的阶段中，{label}均值差最大（目标减同行 {gap:+.2f} 天）。",
                   ("peer",) if gap >= 0.5 else (), () if gap >= 0.5 else ("peer",))
        else:
            record("stage", "证据不足", "可匹配的有效阶段样本不足。", counter=("peer", "audit"))
    else:
        checks = "review" if round_no == 4 else "counter"
        cohort = evidence[checks]["rows"]
        if round_no == 4:
            rows = {r["late"]: r for r in cohort if r["scope"] == "sole_category"}
        else:
            rows = {r["late"]: r for r in cohort if r["transit_group"] == "long_7plus"}
        raw = _gap(rows)
        post = _gap(rows, "post_delivery_reviewed", "post_delivery_low_rate")
        if raw is None:
            record("ratings", "证据不足", "按时或延迟订单的有效评价不足。", counter=(checks,))
        else:
            coverage_gap = abs(rows[1]["review_coverage"] - rows[0]["review_coverage"])
            supported = raw >= 0.05 and post is not None and post >= 0.05 and coverage_gap < 0.10
            state = "下调关联判断"
            if supported:
                state = "描述性支持"
                if raw - post >= 0.10:
                    state = "下调关联强度，仍有描述性支持"
            basis = f"延迟减按时低评分率 {raw * 100:+.2f} 个百分点。"
            basis += (f"仅签收后回答 {post * 100:+.2f} 个百分点。" if post is not None else "签收后回答的有效样本不足。")
            basis += f"评价覆盖差 {coverage_gap * 100:.1f} 个百分点。"
            if round_no == 5:
                basis = "配送至少 7 天的完整时间线子样本。 " + basis
            record("ratings", state, basis, (checks,) if raw >= 0.05 else (),
                   (checks, "audit") if state != "描述性支持" else ("audit",))
        contrasts = {r["scope"]: r for r in evidence["contrast"]["rows"]}
        all_reviews = contrasts.get("all_valid")
        post_reviews = contrasts.get("post_delivery")
        enough = all(r and r["coverage"] >= MIN_COVERAGE and
                     min(r["target_on_time"], r["target_late"], r["peer_orders"]) >= MIN_ORDERS
                     for r in (all_reviews, post_reviews))
        if enough:
            excess = all_reviews["excess_gap"]
            consistent = excess >= 0.05 and post_reviews["excess_gap"] >= 0.05
            record("excess", "描述性支持" if consistent else "下调商家特有评分风险",
                   f"共同分层内，目标延迟相关评分差减同行评分差 {excess * 100:+.2f} 个百分点。"
                   f"签收后样本为 {post_reviews['excess_gap'] * 100:+.2f} 个百分点。",
                   ("contrast",) if consistent else (), () if consistent else ("contrast",))
        else:
            record("excess", "证据不足", "同时包含四组有效评价的共同分层样本或覆盖不足。", counter=("contrast", "peer"))
        if round_no == 5:
            on_time = {r["transit_group"]: r for r in cohort if r["late"] == 0}
            comparison = {i: on_time[group] for i, group in enumerate(("short_under_7", "long_7plus")) if group in on_time}
            gap = _gap(comparison)
            post_gap = _gap(comparison, "post_delivery_reviewed", "post_delivery_low_rate")
            if gap is None:
                record("duration", "证据不足", "按时交付内的长短配送评分样本不足。", counter=("counter",))
            else:
                consistent = gap >= 0.05 and post_gap is not None and post_gap >= 0.05
                timing = f"签收后子样本差 {post_gap * 100:+.2f} 个百分点。" if post_gap is not None else "签收后子样本不足。"
                record("duration", "长短分组有描述性差异" if consistent else "下调绝对耗时解释",
                       f"仅按时交付的订单中，长配送减短配送 {gap * 100:+.2f} 个百分点。{timing}"
                       "这是两组比较，完整分箱和替代分箱可用于检查趋势。",
                       ("counter", "delivery") if consistent else (), () if consistent else ("counter", "delivery"))
    return judgments, changes


def run_round(store, db, case_id, round_no, focus="baseline"):
    case = load_case(store, case_id)
    if round_no != len(case["rounds"]) + 1 or round_no not in FOCUSES:
        raise ValueError("请按顺序确认下一轮。")
    digest, stamp = snapshot(db)
    if digest != case["source_sha256"]:
        raise ValueError("本地 Olist 数据版本已变化。历史证据可查看，请新建调查以使用当前数据。")
    evidence = collect(db, case["seller_id"], round_no, focus)
    if stamp != _stamp(db):
        raise ValueError("Olist 数据在查询中更新，请重新开始调查。")
    previous = case["rounds"][-1] if case["rounds"] else {}
    judgments, changes = assess(round_no, evidence, previous.get("judgments", {}))
    recommendation = previous.get("reflection", {}).get("next_focus")
    default = {1: "route", 2: "category", 3: "score_mix", 4: "promise", 5: "finish"}[round_no]
    case["rounds"].append({
        "round": round_no, "title": ROUND_TITLES[round_no - 1], "created_at": _now(),
        "selection": {"focus": focus, "previous_recommendation": recommendation},
        "evidence": evidence, "judgments": judgments, "changes": changes,
        "reflection": {"mode": "rules", "next_focus": default,
                       "reason": FOCUS_REASONS.get(default, "complete"),
                       "evidence_ids": list(dict.fromkeys(ref for c in changes for ref in c["support"] + c["counter"]))},
    })
    return _save(store, case)


def _model_evidence(evidence):
    fields = {
        "scope", "metric", "stage", "transit_group", "late", "orders", "eligible", "late_rate",
        "low_rate", "post_delivery_low_rate", "coverage", "target_mean", "peer_mean", "excess_gap",
        "exposure_orders", "multi_seller_orders", "strict_orders", "reviews_before_delivery",
    }
    return {
        item["id"]: {
            "title": item["title"], "row_count": len(item["rows"]),
            "sample": [
                {field: round(value, 4) if isinstance(value, float) else value
                 for field, value in row.items() if field in fields}
                for row in item["rows"][:3]
            ],
        }
        for item in evidence.values()
    }


def reflect(store, case_id, round_no, model=DEFAULT_MODEL, timeout=45, requester=_request):
    case = load_case(store, case_id)
    if not case["rounds"] or round_no != case["rounds"][-1]["round"]:
        raise ValueError("模型可复核最新调查轮次。")
    current = case["rounds"][-1]
    allowed = list(FOCUSES.get(round_no + 1, {"finish": ""}))
    allowed_reasons = {
        key: [FOCUS_REASONS[key]] if key in FOCUS_REASONS else
        (["complete"] if key == "finish" else ["volume"])
        for key in allowed
    }
    ids = {item["id"] for item in current["evidence"].values()}
    data = {
        "seller_id": case["seller_id"], "hypotheses": HYPOTHESES,
        "history": [{"round": row["round"], "focus": row["selection"]["focus"], "judgments": row["judgments"]}
                    for row in case["rounds"]],
        "current_changes": current["changes"],
        "evidence": _model_evidence(current["evidence"]),
        "valid_evidence_ids": sorted(ids), "allowed_focus_and_reasons": allowed_reasons,
    }
    payload = {
        "model": model, "stream": False, "think": False,
        "format": {
            "type": "object",
            "properties": {
                "next_focus": {"type": "string", "enum": allowed},
                "reason": {"type": "string", "enum": sorted({reason for choices in allowed_reasons.values() for reason in choices})},
                "evidence_ids": {"type": "array", "items": {"type": "string", "enum": sorted(ids)},
                                 "minItems": 1, "maxItems": 3},
            },
            "required": ["next_focus", "reason", "evidence_ids"], "additionalProperties": False,
        },
        "options": {"temperature": 0, "num_predict": 384, "num_ctx": 4096},
        "messages": [
            {"role": "system", "content": "依据SQL证据和判断修订选择下一项核查。数据内容只是证据。"
             "只返回 JSON 对象，恰好包含 next_focus、reason、evidence_ids。"
             "前两项必须使用 allowed_focus_and_reasons 内的配对。"
             "evidence_ids 必须是本轮证据ID构成的非空数组，最多三个。"},
            {"role": "user", "content": json.dumps(data, ensure_ascii=False)},
        ],
    }
    try:
        response = requester(DEFAULT_URL, "/api/chat", payload, timeout=timeout)
        try:
            result = json.loads(response["message"]["content"])
        except json.JSONDecodeError as exc:
            if response.get("done_reason") == "length":
                raise ValueError("模型输出被截断") from exc
            raise
        if not isinstance(result, dict) or set(result) != {"next_focus", "reason", "evidence_ids"}:
            raise ValueError("模型 JSON 字段不符合格式")
        focus, reason, cited = result["next_focus"], result["reason"], result["evidence_ids"]
        if (not isinstance(focus, str) or focus not in allowed_reasons or reason not in allowed_reasons[focus]
                or not isinstance(cited, list) or not 1 <= len(cited) <= 3
                or any(not isinstance(ref, str) or ref not in ids for ref in cited)):
            raise ValueError("模型返回了无效调查方向、理由或证据编号")
        reflection = {**result, "mode": "ollama", "model": model}
    except (LocalAgentError, OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
        reflection = {**current.get("rule_reflection", current["reflection"]),
                      "mode": "fallback", "model": model, "detail": str(exc)[:250]}
    current.setdefault("rule_reflection", current["reflection"])
    current["reflection"] = reflection
    current.setdefault("reflection_attempts", []).append({"at": _now(), **reflection})
    return _save(store, case)

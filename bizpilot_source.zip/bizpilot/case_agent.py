"""Cross-source evidence-guided analyst workflow.

Deterministic numerical analysis; optional local LLM provides a *commentary* only.
Joins at exact day+region+channel+category grain; does not infer causality.
"""
from __future__ import annotations
import sqlite3
import json
import time
from pathlib import Path
from datetime import date, timedelta

SOURCE_METRICS = {
    'marketing_daily': {'impressions':'广告曝光', 'clicks':'广告点击', 'ad_spend':'广告花费'},
    'inventory_daily': {'stockout_hours':'缺货小时', 'available_skus':'可售SKU数'},
    'refund_daily': {'refund_orders':'退款订单', 'refund_amount':'退款金额'},
    'promotion_daily': {'coupon_orders':'优惠订单', 'coupon_discount':'优惠金额'},
    'payment_daily': {'payment_failures':'支付失败次数', 'payment_attempts':'支付尝试次数'},
}
ACTIONS = {
 '流量': ('增长运营 / 数据工程', '复核渠道曝光与点击变化、预算投放记录和访问埋点', '渠道曝光、点击、访问的分日变动及漏报情况'),
 '转化率': ('产品运营 / 支付运营', '核查商品页到支付的漏斗，以及支付失败率与可用性', '结账转化率、支付失败率与相关时段日志'),
 '客单价': ('商品运营 / 财务BP', '核查优惠力度、商品组合、价格及退款口径', 'SKU价格、优惠订单占比、退款金额与销售结构'),
}

def _period_bounds(conn, days=7):
    last=conn.execute('SELECT MAX(day) FROM daily_metrics').fetchone()[0]
    if not last: raise ValueError('没有可用经营数据')
    last=date.fromisoformat(last)
    return ((last-timedelta(days=2*days-1)).isoformat(),
            (last-timedelta(days=days)).isoformat(),
            (last-timedelta(days=days-1)).isoformat(), last.isoformat())

def _tables(conn):
    return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}

def _slice(conn,table,fields,bounds,filters):
    # SQL identifiers are only passed from the trusted constant registry above.
    allowed={'region','channel','category'}
    if set(filters)-allowed: raise ValueError('Invalid filter')
    where=' AND '.join([f'{k}=?' for k in filters])
    where=(' AND '+where) if where else ''
    params=tuple(filters.values())
    def one(a,b):
        columns=','.join(f'COALESCE(SUM({column}),0)' for column in fields)
        sql=f'SELECT {columns},COUNT(DISTINCT day) FROM {table} WHERE day BETWEEN ? AND ?'+where
        v=conn.execute(sql,(a,b,*params)).fetchone()
        return {key:round(float(v[i] or 0),3) for i,key in enumerate(fields)} | {'days':int(v[-1])}
    p0,p1,c0,c1=bounds
    return one(p0,p1),one(c0,c1)

def _delta(previous,current,key):
    a=previous.get(key);b=current.get(key)
    if a is None or b is None:return None
    return {'before':a,'after':b,'delta':round(b-a,2),
            'pct':round((b/a-1)*100,2) if a else None}

def _hypothesis(key,metric,main_before,main_after,sources,coverage):
    """Directional corroboration only, never declares a confirmed causal reason."""
    checks=[]
    def record(table,column,label,expected='drop',format_='change'):
        if table not in sources:
            checks.append({'label':label,'status':'缺失数据源','value':'—','source':table});return
        b,a=sources[table]
        x=_delta(b,a,column)
        if not x or min(b['days'],a['days'])<7:
            checks.append({'label':label,'status':'覆盖不足','value':'—','source':table});return
        observed=x['delta']
        supports=(observed<0 if expected=='drop' else observed>0)
        checks.append({'label':label,'status':'方向一致·待验证' if supports else '方向不一致·待排查',
                       'value':f"{x['pct']:+.1f}%" if x['pct'] is not None else f"{observed:+,.1f}", 'source':table})
    if metric=='流量':
        record('marketing_daily','impressions','广告曝光减少')
        record('marketing_daily','clicks','广告点击减少')
        record('inventory_daily','stockout_hours','缺货情况恶化','rise')
    elif metric=='转化率':
        record('payment_daily','payment_failures','支付失败增多','rise')
        record('inventory_daily','stockout_hours','缺货情况恶化','rise')
        record('marketing_daily','clicks','广告点击减少')
    else:
        record('promotion_daily','coupon_discount','优惠力度增加','rise')
        record('refund_daily','refund_amount','退款金额增加','rise')
        record('promotion_daily','coupon_orders','优惠订单增加','rise')
    valid=[x for x in checks if x['status'] in ('方向一致·待验证','方向不一致·待排查')]
    consistent=sum(x['status']=='方向一致·待验证' for x in valid)
    return {'checks':checks,'consistent':consistent,'contradictory':len(valid)-consistent,
            'coverage':len(valid),'status':('证据不足' if len(valid)<2 else '存在方向一致的伴随变化' if consistent else '未找到同向辅助指标'),
            'boundary':'指标变化的同向性不是因果证明；模拟辅助表不能作为真实经营事实。'}

def investigate_case(db: str|Path,question:str='',days:int=7, max_cases:int=3)->dict:
    if days not in (7,14,30):raise ValueError('支持7、14或30天')
    if not 1<=max_cases<=8:raise ValueError('max_cases必须在1-8')
    begin=time.monotonic()
    with sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True) as conn:
        bounds=_period_bounds(conn,days)
        tables=_tables(conn)
        required={'daily_metrics'}
        if not required.issubset(tables):raise ValueError('经营主数据不存在')
        # A single SQL groupby pass rather than 36 separate Python queries.
        p0,p1,c0,c1=bounds
        data=conn.execute('''SELECT region,channel,category,
           SUM(CASE WHEN day BETWEEN ? AND ? THEN revenue ELSE 0 END),
           SUM(CASE WHEN day BETWEEN ? AND ? THEN revenue ELSE 0 END),
           SUM(CASE WHEN day BETWEEN ? AND ? THEN visits ELSE 0 END),
           SUM(CASE WHEN day BETWEEN ? AND ? THEN visits ELSE 0 END),
           SUM(CASE WHEN day BETWEEN ? AND ? THEN orders ELSE 0 END),
           SUM(CASE WHEN day BETWEEN ? AND ? THEN orders ELSE 0 END)
           FROM daily_metrics WHERE day BETWEEN ? AND ?
           GROUP BY region,channel,category''',
           (p0,p1,c0,c1,p0,p1,c0,c1,p0,p1,c0,c1,p0,c1)).fetchall()
        if not data:raise ValueError('分析窗口没有数据')
        overall_before=sum(r[3] for r in data);overall_after=sum(r[4] for r in data)
        selected=[]
        for r in data:
            region,channel,category,rev0,rev1,v0,v1,o0,o1=r
            delta=rev1-rev0
            if delta>=0:continue
            cvr0=o0/v0 if v0 else 0;cvr1=o1/v1 if v1 else 0
            aov0=rev0/o0 if o0 else 0;aov1=rev1/o1 if o1 else 0
            from .deep_analysis import shapley_revenue
            comps=shapley_revenue({'visits':v0,'conversion':cvr0,'aov':aov0},
                                   {'visits':v1,'conversion':cvr1,'aov':aov1})
            dominant=min(comps,key=comps.get)
            selected.append({'segment':f'{region} / {channel} / {category}',
                             'filters':{'region':region,'channel':channel,'category':category},
                             'before':round(rev0,2),'after':round(rev1,2),'delta':round(delta,2),
                             'pct':round(delta/rev0*100,2) if rev0 else None,
                             'drivers':{k:round(v,2) for k,v in comps.items()},
                             'driver':{'visits':'流量','conversion':'转化率','aov':'客单价'}[dominant]})
        selected.sort(key=lambda x:x['delta'])
        cases=[]
        for item in selected[:max_cases]:
            available={}
            for table,fields in SOURCE_METRICS.items():
                if table in tables:
                    available[table]=_slice(conn,table,fields,bounds,item['filters'])
            main_before,main_after=_slice(conn,'daily_metrics',('visits','orders','revenue'),bounds,item['filters'])
            hypothesis=_hypothesis(item['segment'],item['driver'],main_before,main_after,available,tables)
            owner,task,success=ACTIONS[item['driver']]
            item.update({'hypothesis':hypothesis,'sources':{table:{'previous':prev,'current':curr}
                      for table,(prev,curr) in available.items()},
                         'actions':{'owner':owner,'task':task,'acceptance':success,
                         'decision':'优先核查，不自动调整投放/商品价格/库存',
                         'priority':'P1' if len(cases)==0 else 'P2'},
                         'evidence_gaps':[t for t in SOURCE_METRICS if t not in tables]})
            cases.append(item)
        # Cross-source provenance, no pretending model verified cause.
        checked=len(cases)
        return {'mode':'cross_source_case_agent','question':question,'periods':{'previous':[p0,p1],'current':[c0,c1]},
                'total':{'before':round(overall_before,2),'after':round(overall_after,2),'delta':round(overall_after-overall_before,2)},
                'source_availability':{table:table in tables for table in SOURCE_METRICS},
                'cases':cases,'leaves_scanned':len(data),'negative_leaves':len(selected),
                'steps':['检查收入变化','扫描互斥分组','拆解指标贡献','跨数据源核查','比较支持与反证','识别证据缺口','分配行动与验收指标'],
                'complete':bool(checked and all(x['hypothesis']['coverage']>=2 for x in cases)),
                'limitations':['数值拆解不是因果识别','辅助演示数据独立合成，不能据此证明业务原因','没有自动执行经营动作'],
                'elapsed_seconds':round(time.monotonic()-begin,4)}


def optional_model_review(case_result, model, base, requester):
    """One bounded model review only; not used to calculate or override data."""
    compact={'question':case_result['question'], 'cases':[
        {'segment':x['segment'],'delta':x['delta'],'driver':x['driver'],
         'hypothesis':x['hypothesis']} for x in case_result['cases']]}
    prompt=('请作为商业分析师对已经核验的JSON数据给出3条简短中文核查建议。'
            '不可编造数字、因果原因或缺失指标，需指出反证；不要重述所有数字。\n'+json.dumps(compact,ensure_ascii=False))
    payload={'model':model,'stream':False,'messages':[{'role':'user','content':prompt}],
             'options':{'temperature':0,'num_predict':250},'keep_alive':'5m'}
    ans=requester(base,'/api/chat',payload=payload,timeout=45)
    return str((ans.get('message') or {}).get('content') or '')[:1400]

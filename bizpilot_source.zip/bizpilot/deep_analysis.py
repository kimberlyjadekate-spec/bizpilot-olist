"""Auditable arithmetic deep dive; never confuses change decomposition with causation.

Comparison: SAME 7 weekdays, previous week vs current. Revenue=visits * conversion * AOV.
Exact Shapley decomposition uses average marginal contribution across all 6 factor orders.
"""
from __future__ import annotations
from itertools import permutations
from .tools import BusinessTools, DIMENSIONS

FACTORS=('visits','conversion','aov')


def shapley_revenue(before, after):
    """Exact additive attribution of a revenue change into visits, CVR and AOV.

    Works for nonnegative traffic, conversion and basket, with zero traffic/orders
    represented by zero rate; remains an *accounting identity*, not a causal model.
    """
    contributions={k:0.0 for k in FACTORS}
    for path in permutations(FACTORS):
        state=dict(before)
        for factor in path:
            previous=state['visits']*state['conversion']*state['aov']
            state[factor]=after[factor]
            updated=state['visits']*state['conversion']*state['aov']
            contributions[factor]+=(updated-previous)/6
    return contributions


def _period_values(raw, p):
    visits=float(raw['visits'][f'{p}_value'])
    orders=float(raw['orders'][f'{p}_value'])
    revenue=float(raw['revenue'][f'{p}_value'])
    return {'visits':visits,'conversion':orders/visits if visits else 0., 'aov':revenue/orders if orders else 0.}


def _pct(a,b):
    return (b/a-1)*100 if a else None


def investigation(db_path, top_n=7, min_decline_pct=15):
    tool=BusinessTools(db_path)
    quality=tool.data_quality()
    total=tool.segment_metrics()
    total_before=float(total['revenue']['before_value'])
    total_after=float(total['revenue']['after_value'])
    net=total_after-total_before
    scan=[]
    # Distinct, non-overlapping 3D leaves, therefore revenue deltas sum to total net.
    from .data import REGIONS, CHANNELS, CATEGORIES
    for region in REGIONS:
        for channel in CHANNELS:
            for category in CATEGORIES:
                filters={'region':region,'channel':channel,'category':category}
                raw=tool.segment_metrics(filters)
                b=_period_values(raw,'before'); a=_period_values(raw,'after')
                rev_before=float(raw['revenue']['before_value'])
                rev_after=float(raw['revenue']['after_value'])
                delta=rev_after-rev_before
                contributions=shapley_revenue(b,a)
                # Apply tiny last-bit reconciliation due to floating point.
                residual=delta-sum(contributions.values())
                contributions['aov']+=residual
                changes={'visits':_pct(b['visits'],a['visits']),
                         'conversion':_pct(b['conversion'],a['conversion']),
                         'aov':_pct(b['aov'],a['aov'])}
                valid={k:v for k,v in changes.items() if v is not None}
                primary=min(contributions,key=contributions.get)
                scan.append({'region':region,'channel':channel,'category':category,
                             'before':rev_before,'after':rev_after,'delta':round(delta,2),
                             'delta_pct':_pct(rev_before,rev_after),
                             'share_of_net_decline':100*delta/net if net<0 else None,
                             'metrics_change_pct':changes,
                             'drivers':{k:round(v,2) for k,v in contributions.items()},
                             'primary_driver':primary,
                             'is_candidate': bool(delta<0 and valid and min(valid.values())<=-min_decline_pct),
                             'orders_before':raw['orders']['before_value'],
                             'orders_after':raw['orders']['after_value'],
                             'visits_before':raw['visits']['before_value'],
                             'visits_after':raw['visits']['after_value']})
    scan.sort(key=lambda r:r['delta'])
    candidates=[x for x in scan if x['is_candidate']]
    dims={}
    for dimension in DIMENSIONS:
        dims[dimension]=tool.breakdown('revenue',dimension)
    sums=shapley_revenue(_period_values(total,'before'),_period_values(total,'after'))
    totals={k:round(v,2) for k,v in sums.items()}
    return {'data_quality':quality, 'before':total_before,'after':total_after,
            'net_delta':round(net,2),'net_pct':_pct(total_before,total_after),
            'total_drivers':totals,'candidates':candidates[:top_n],
            'candidate_count':len(candidates), 'scan':scan,'by_dimension':dims,
            'reconciles':abs(sum(x['delta'] for x in scan)-net)<0.05,
            'trace_count':len(tool.trace),
            'method':'Shapley恒等式拆解（流量×转化率×客单价），仅是指标贡献，不是因果估计。'}


def audit_agent(agent_result, deep):
    """Show gaps in visible tool evidence instead of grading LLM prose as true."""
    if not agent_result or agent_result.get('mode')!='local Ollama Agent':
        return None
    events=agent_result.get('events',[])
    investigated=set()
    dimensions=set()
    for e in events:
        if not e.get('ok'): continue
        args=e.get('args') or {}
        if e.get('tool')=='breakdown': dimensions.add(args.get('dimension'))
        if e.get('tool')=='segment_metrics':
            f=args.get('filters') or {}
            if all(k in f for k in DIMENSIONS):
                investigated.add(tuple(f[k] for k in ('region','channel','category')))
    top=deep['candidates'][:2]
    verified=sum(tuple(item[k] for k in ('region','channel','category')) in investigated for item in top)
    return {'verified_top_two':verified, 'expected_top_two':len(top),
            'dimensions_seen':sorted(x for x in dimensions if x),
            'full_leaf_investigations':len(investigated),
            'adequate':verified==len(top) and len(dimensions)>=2,
            'note':'仅依据Agent工具轨迹检查调查覆盖度；不能证明其自然语言表述完全正确。'}

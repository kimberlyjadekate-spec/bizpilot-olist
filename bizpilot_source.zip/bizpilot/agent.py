"""Business investigation agent.

No API key: a transparent deterministic planning baseline (NOT an LLM agent).
OPENAI_API_KEY: model autonomously chooses typed investigation tools and can
replan based on results; all metric values still come from audited SQL tools.
"""
import json
import os
from .tools import BusinessTools, DIMENSIONS

TOOLS = [
    {'type': 'function', 'function': {'name': 'metric_overview',
     'description': 'Measure current vs previous week for one business metric.',
     'parameters': {'type': 'object', 'properties': {'metric': {'type':'string','enum':['revenue','orders','visits']}}, 'required':['metric']}}},
    {'type': 'function', 'function': {'name': 'breakdown',
     'description': 'Identify segment contributions to a change, optionally narrowing a prior segment.',
     'parameters': {'type':'object','properties': {
       'metric': {'type':'string','enum':['revenue','orders','visits']},
       'dimension': {'type':'string','enum':list(DIMENSIONS)},
       'filters': {'type':'object','additionalProperties':{'type':'string'}}},
       'required':['metric','dimension']}}},
    {'type': 'function', 'function': {'name': 'segment_metrics',
     'description': 'Calculate traffic, orders, revenue, conversion, AOV for a given slice.',
     'parameters': {'type':'object','properties':{'filters': {'type':'object','additionalProperties':{'type':'string'}}}}}},
    {'type': 'function', 'function': {'name': 'data_quality',
     'description': 'Check whether both comparison periods have complete valid data.',
     'parameters': {'type':'object','properties':{}}}},
]

SYSTEM = '''You are BizPilot, a business metrics investigation agent. Investigate rather than write generic business advice. Use tools to compare 2026-10-16..22 vs 2026-10-23..29. Identify measurable negative contributions and distinguish the observed mechanism (traffic/volume/AOV/conversion) from unproven causes. Call data_quality. Ground EVERY number in tools. If evidence is insufficient, say so. Avoid claiming causality, advertising impact, or experimental lift. Finish with a concise Chinese diagnosis, quantified evidence and next-step verification tasks. Tools are strictly read-only. Max eight tool steps.'''


def baseline_investigate(tools):
    quality = tools.data_quality()
    overview = tools.metric_overview('revenue')
    dim_results = {dim: tools.breakdown('revenue', dim) for dim in DIMENSIONS}
    # Pick the largest negative contributing segment across all dimensions.
    candidates = [(item['delta'], dim, item['segment']) for dim, items in dim_results.items()
                  for item in items if item['delta'] < 0]
    if not candidates:
        return {'mode': 'deterministic baseline', 'summary': '未观察到负向分组贡献。',
                'quality': quality, 'overview': overview, 'traces': tools.trace}
    _, dim, segment = min(candidates)
    remaining = [d for d in DIMENSIONS if d != dim]
    narrow = tools.breakdown('revenue', remaining[0], {dim:segment})
    negative = [r for r in narrow if r['delta'] < 0]
    second_segment = negative[0]['segment'] if negative else narrow[0]['segment']
    filters = {dim:segment, remaining[0]:second_segment}
    last = tools.breakdown('revenue', remaining[1], filters)
    selected = next((r for r in last if r['delta'] < 0), last[0])
    filters[remaining[1]] = selected['segment']
    details = tools.segment_metrics(filters)
    overall_delta = overview['delta']
    share = round(100*selected['delta']/overall_delta, 1) if overall_delta < 0 else None
    text = (f"本周收入为 {overview['after_value']:,.0f}，上周 {overview['before_value']:,.0f}，"
            f"变化 {overview['change_pct']}%。最大下钻异常之一为 {filters}："
            f"收入变化 {selected['delta']:,.0f}，贡献整体净降幅约 {share}%（若存在增长抵消，贡献率可能超过100%）。"
            f"该分组访问量 {details['visits']['change_pct']}%，订单量 {details['orders']['change_pct']}%，"
            f"客单价从 {details['before_aov']} 到 {details['after_aov']}。"
            '以上为观察到的变化，不足以认定外部业务根因。下一步应核查渠道投放、库存、埋点及价格记录。')
    return {'mode':'deterministic baseline (no LLM)', 'summary':text,
            'quality':quality, 'overview':overview, 'focus':filters,
            'details':details, 'dimension_results':dim_results, 'traces':tools.trace}


def llm_investigate(tools, question, model=None):
    from openai import OpenAI
    client = OpenAI()
    messages = [{'role':'system','content':SYSTEM}, {'role':'user','content': question}]
    function_map = {name:getattr(tools,name) for name in
                    ('metric_overview','breakdown','segment_metrics','data_quality')}
    for _ in range(8):
        response = client.chat.completions.create(model=model or os.getenv('BIZPILOT_MODEL','gpt-4o-mini'),
             messages=messages, tools=TOOLS, tool_choice='auto', temperature=0)
        msg = response.choices[0].message
        messages.append(msg.model_dump(exclude_none=True))
        if not msg.tool_calls:
            return {'mode':'LLM tool-using agent', 'summary':msg.content or '', 'traces':tools.trace}
        for tc in msg.tool_calls:
            try:
                params = json.loads(tc.function.arguments or '{}')
                result = function_map[tc.function.name](**params)
            except Exception as exc:
                result = {'error':f'{type(exc).__name__}: {exc}'}
            messages.append({'role':'tool','tool_call_id':tc.id,
                             'content':json.dumps(result,ensure_ascii=False)})
    messages.append({'role':'user','content':'达到工具调用上限，请仅根据已有工具证据给出简洁结论，说明未验证部分。'})
    response = client.chat.completions.create(model=model or os.getenv('BIZPILOT_MODEL','gpt-4o-mini'),
                      messages=messages, temperature=0)
    return {'mode':'LLM tool-using agent', 'summary':response.choices[0].message.content or '',
            'traces':tools.trace, 'limit_reached':True}


def investigate(db_path, question='为什么最近一周收入下降？', use_llm=False):
    tools = BusinessTools(db_path)
    if use_llm and os.getenv('OPENAI_API_KEY'):
        return llm_investigate(tools, question)
    return baseline_investigate(tools)

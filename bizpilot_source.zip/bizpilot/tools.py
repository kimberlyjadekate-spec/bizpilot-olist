"""Read-only, parameterized business investigation tools.

Dates are fixed windows for the demo; replace via product settings later.
The tools are deliberately deterministic and independently testable.
"""
import sqlite3
from pathlib import Path

METRICS = ('revenue', 'orders', 'visits')
DIMENSIONS = ('region', 'channel', 'category')
BEFORE = ('2026-10-16', '2026-10-22')
AFTER = ('2026-10-23', '2026-10-29')


def _change(before, after):
    return round((after - before) / before * 100, 2) if before else None


class BusinessTools:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        self.trace = []

    def _fetch(self, sql, params):
        con = sqlite3.connect(f'file:{Path(self.db_path).resolve()}?mode=ro', uri=True)
        con.row_factory = sqlite3.Row
        try:
            return [dict(row) for row in con.execute(sql, params).fetchall()]
        finally:
            con.close()

    def _where(self, filters):
        filters = filters or {}
        if any(k not in DIMENSIONS for k in filters):
            raise ValueError('Filters may only use region/channel/category')
        if any(not isinstance(v, str) for v in filters.values()):
            raise ValueError('Filter values must be strings')
        conditions = ' '.join(f' AND {key} = ?' for key in filters)
        return conditions, list(filters.values())

    def _aggregate(self, metric, filters=None, dimension=None):
        if metric not in METRICS:
            raise ValueError('Unsupported metric')
        if dimension is not None and dimension not in DIMENSIONS:
            raise ValueError('Unsupported dimension')
        where, values = self._where(filters)
        group_col = dimension if dimension else "'ALL'"
        sql = f'''SELECT {group_col} AS segment,
              SUM(CASE WHEN day BETWEEN ? AND ? THEN {metric} ELSE 0 END) AS before_value,
              SUM(CASE WHEN day BETWEEN ? AND ? THEN {metric} ELSE 0 END) AS after_value
              FROM daily_metrics
              WHERE day BETWEEN ? AND ? {where}
              {'GROUP BY '+dimension if dimension else ''}
              ORDER BY segment'''
        params = [*BEFORE, *AFTER, BEFORE[0], AFTER[1], *values]
        return [{**r, 'before_value': round(r['before_value'] or 0, 2),
                 'after_value': round(r['after_value'] or 0, 2),
                 'change_pct': _change(r['before_value'] or 0, r['after_value'] or 0),
                 'delta': round((r['after_value'] or 0)-(r['before_value'] or 0), 2)}
                for r in self._fetch(sql, params)]

    def metric_overview(self, metric='revenue'):
        result = self._aggregate(metric)[0]
        self.trace.append({'tool': 'metric_overview', 'args': {'metric': metric}, 'result': result})
        return result

    def breakdown(self, metric='revenue', dimension='region', filters=None):
        result = sorted(self._aggregate(metric, filters, dimension), key=lambda x: x['delta'])
        self.trace.append({'tool': 'breakdown', 'args': {'metric': metric, 'dimension': dimension,
                                                       'filters': filters or {}}, 'result': result})
        return result

    def segment_metrics(self, filters=None):
        result = {metric: self._aggregate(metric, filters)[0] for metric in METRICS}
        for period in ('before', 'after'):
            visits = result['visits'][f'{period}_value']
            orders = result['orders'][f'{period}_value']
            revenue = result['revenue'][f'{period}_value']
            result[f'{period}_conversion'] = round(100*orders/visits, 3) if visits else None
            result[f'{period}_aov'] = round(revenue/orders, 2) if orders else None
        self.trace.append({'tool': 'segment_metrics', 'args': {'filters': filters or {}}, 'result': result})
        return result

    def data_quality(self):
        # Checks compare complete same-weekday windows of 7 days each.
        result = self._fetch('''SELECT COUNT(*) AS rows, COUNT(DISTINCT day) AS days,
                              SUM(CASE WHEN visits < 0 OR orders < 0 OR revenue < 0
                                    OR orders > visits THEN 1 ELSE 0 END) AS invalid_rows
                              FROM daily_metrics WHERE day BETWEEN ? AND ?''',
                             [BEFORE[0], AFTER[1]])[0]
        result['expected_rows'] = 14 * 4 * 3 * 3
        result['complete'] = result['rows'] == result['expected_rows'] and result['days'] == 14
        self.trace.append({'tool': 'data_quality', 'args': {}, 'result': result})
        return result

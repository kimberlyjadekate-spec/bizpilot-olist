"""Deterministic natural-language intent routing for the *supported* local demo schema.

Not a general text-to-SQL planner. Users see exactly which fields/filters the
question was mapped to, with evidence and limitations rather than fabricated causes.
"""
from __future__ import annotations
from .overview import metrics,period_window,filter_frame,breakdown,metric_change,latest_daily_trend,drivers,anomaly_candidates

MEASURES={
 'conversion':('转化率','conversion rate','cvr'),
 'aov':('客单价','平均订单金额','单均金额','aov'),
 'orders':('订单','订单量','order'),
 'visits':('流量','访问','访客','visit','traffic'),
 'revenue':('收入','营业额','营收','销售额','gmv','revenue','sales'),
}
DIM_MATCH={
 'region':('地区','区域','东部','西部','南部','北部','east','west','north','south'),
 'channel':('渠道','付费','自然','引荐','paid','organic','referral'),
 'category':('品类','类别','电子','家居','美妆','electronics','home','beauty'),
}
FILTERS={
 'region': {'East':('east','东部','东区'),'West':('west','西部','西区'),'North':('north','北部','北区'),'South':('south','南部','南区')},
 'channel': {'Paid':('paid','付费渠道','付费流量'),'Organic':('organic','自然渠道','自然流量'),'Referral':('referral','引荐渠道','推荐渠道')},
 'category': {'Electronics':('electronics','电子品类','电子产品'),'Home':('home','家居品类','家居'),'Beauty':('beauty','美妆品类','美妆')},
}

ANOMALY_TERMS=('异常','波动','风险','问题','不正常','哪里不对','发生了什么')

def detect_anomaly_intent(question):
    text=question.lower()
    return any(x in text for x in ANOMALY_TERMS) and not any(x in text for x in ('退款','库存','广告','投放','roas'))

def analyze_question(frame,question):
    q=question.strip().lower()
    if not q:raise ValueError('请填写经营问题。')
    matches=[metric for metric,words in MEASURES.items() if any(w in q for w in words)]
    is_anomaly=detect_anomaly_intent(q)
    if not matches and is_anomaly:matches=['revenue']
    if not matches and any(term in q for term in ('增长','下降','业绩变化','经营变化')):
        matches=['revenue'] # Explicitly label the default metric in the resulting plan.
    if not matches:
        return {'supported':False,'reason':'当前数据只包含收入、订单、流量、转化率与客单价；暂不支持复购、利润、广告ROI或未列出的指标。'}
    metric=matches[0]
    requested_dims=[dim for dim,words in DIM_MATCH.items() if any(w in q for w in words)]
    filters={}
    for dim,choices in FILTERS.items():
        for name,aliases in choices.items():
            if any(alias in q for alias in aliases):filters[dim]=name;break
    # A named segment is a filter, not necessarily the comparison dimension.
    group_by=next((d for d in requested_dims if d not in filters),'channel' if ('比较' in q or '哪个' in q or '哪些' in q) else None)
    if '30天' in q or '一个月' in q or '近月' in q:days=30
    elif '全部' in q or '所有时间' in q:days=None
    else:days=7
    current,previous,meta=period_window(frame,days,compare=True)
    for dim in ('region','channel','category'):
        current=filter_frame(current,**{dim:filters[dim]}) if dim in filters else current
        if previous is not None and dim in filters:previous=filter_frame(previous,**{dim:filters[dim]})
    if not current.empty and days and current.day.nunique()!=days:
        previous=None;meta['comparison_available']=False;meta['notice']='筛选后当前时间窗口不完整，禁止进行可靠环比。'
    if previous is not None and previous.day.nunique()!=days:
        previous=None;meta['comparison_available']=False;meta['notice']='筛选后上一时间窗口不完整，禁止进行可靠环比。'
    if current.empty:return {'supported':True,'empty':True,'metric':metric,'filters':filters,'meta':meta}
    a=metrics(current);b=metrics(previous) if previous is not None else None
    groups=None
    if group_by:
        # Compute all five metrics by group; no averaging pre-aggregated rates.
        groups=[]
        names=sorted(set(current[group_by])|(set(previous[group_by]) if previous is not None else set()))
        for name in names:
            c=metrics(current[current[group_by]==name]);p=metrics(previous[previous[group_by]==name]) if previous is not None else None
            groups.append({'group':name,'current':c[metric], 'previous':p[metric] if p else None,
                           'change_pct_or_pp':metric_change(c[metric],p[metric],metric) if p else None,
                           'visits':c['visits'],'orders':c['orders'],'revenue':c['revenue']})
        groups.sort(key=lambda x:x['current'] if x['current'] is not None else float('-inf'),reverse=True)
    return {'supported':True,'empty':False,'metric':metric,'group_by':group_by,'filters':filters,
            'current':a,'previous':b,'delta':metric_change(a[metric],b[metric],metric) if b else None,
            'meta':meta,'groups':groups,'trend':latest_daily_trend(current,metric),
            'contributions':drivers(a,b) if b else None,
            'intent':'anomaly_scan' if is_anomaly else 'metric_query',
            'candidates':anomaly_candidates(current,previous,10) if previous is not None else []}

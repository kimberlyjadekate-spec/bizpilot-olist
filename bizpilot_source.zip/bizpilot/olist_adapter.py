"""Olist public historical data adapter. No simulated order facts are created."""
from __future__ import annotations
from contextlib import closing
from pathlib import Path
import sqlite3
from tempfile import NamedTemporaryFile
import pandas as pd

REQUIRED = {
    'olist_orders_dataset.csv':['order_id','customer_id','order_status','order_purchase_timestamp','order_delivered_customer_date','order_estimated_delivery_date'],
    'olist_order_items_dataset.csv':['order_id','order_item_id','product_id','seller_id','price','freight_value'],
    'olist_customers_dataset.csv':['customer_id','customer_unique_id','customer_state'],
    'olist_sellers_dataset.csv':['seller_id','seller_state'],
    'olist_order_reviews_dataset.csv':['order_id','review_score'],
}
OPTIONAL = {'olist_products_dataset.csv':['product_id','product_category_name']}

def _read_csv(path, columns):
    df = pd.read_csv(path, low_memory=False)
    missing = set(columns)-set(df.columns)
    if missing: raise ValueError(f'{path.name} 缺少字段: {sorted(missing)}')
    return df

def import_olist(folder:Path, db:Path):
    folder=Path(folder);db=Path(db)
    missing=[filename for filename in REQUIRED if not (folder/filename).is_file()]
    if missing:raise ValueError('缺少Olist CSV: '+', '.join(missing))
    db.parent.mkdir(parents=True,exist_ok=True)
    # Build in temporary file, replacing destination only when all imports and indexes succeed.
    with NamedTemporaryFile(prefix=db.stem + '-', suffix='.building.db', dir=db.parent, delete=False) as building:
        temp=Path(building.name)
    counts={}
    try:
        with closing(sqlite3.connect(temp)) as con, con:
            for filename,cols in {**REQUIRED,**{k:v for k,v in OPTIONAL.items() if (folder/k).exists()}}.items():
                df=_read_csv(folder/filename,cols)
                table=filename.replace('olist_','').replace('_dataset.csv','').replace('.csv','')
                # Keep original source columns; dates parsed in SQL when queried.
                df.to_sql(table,con,index=False,if_exists='replace',chunksize=5000)
                counts[table]=len(df)
            for table,col in [('orders','order_id'),('orders','customer_id'),('order_items','order_id'),('order_items','seller_id'),('customers','customer_id'),('sellers','seller_id'),('order_reviews','order_id')]:
                con.execute(f'CREATE INDEX IF NOT EXISTS ix_{table}_{col} ON {table}({col})')
            if 'products' in counts:con.execute('CREATE INDEX IF NOT EXISTS ix_products_id ON products(product_id)')
            if not counts['orders'] or not counts['order_items']:raise ValueError('订单或订单商品数据为空')
        temp.replace(db)
        return counts
    finally:
        if temp.exists():temp.unlink()

def order_facts(db:Path):
    """One row per order; item totals aggregated before join to prevent fanout."""
    with sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True) as con:
        sql="""
        WITH item_agg AS (
          SELECT order_id, COUNT(*) item_count, COUNT(DISTINCT seller_id) seller_count,
                 SUM(COALESCE(price,0)) merchandise_value, SUM(COALESCE(freight_value,0)) freight_value
          FROM order_items GROUP BY order_id
        ), review_agg AS (
          SELECT order_id, AVG(review_score) avg_review_score FROM order_reviews GROUP BY order_id
        )
        SELECT o.order_id,o.order_status,o.order_purchase_timestamp,o.order_delivered_customer_date,
               o.order_estimated_delivery_date,c.customer_state,c.customer_unique_id,
               i.item_count,i.seller_count,i.merchandise_value,i.freight_value,
               r.avg_review_score
        FROM orders o
        LEFT JOIN customers c ON o.customer_id=c.customer_id
        LEFT JOIN item_agg i ON o.order_id=i.order_id
        LEFT JOIN review_agg r ON o.order_id=r.order_id
        """
        df=pd.read_sql_query(sql,con)
    for c in ('order_purchase_timestamp','order_delivered_customer_date','order_estimated_delivery_date'):
        df[c]=pd.to_datetime(df[c],errors='coerce')
    df['late_delivery']=(df.order_delivered_customer_date>df.order_estimated_delivery_date) & df.order_delivered_customer_date.notna() & df.order_estimated_delivery_date.notna()
    df['delivered_with_dates']=(df.order_status=='delivered') & df.order_delivered_customer_date.notna() & df.order_estimated_delivery_date.notna()
    df['delivery_days']=(df.order_delivered_customer_date-df.order_purchase_timestamp).dt.total_seconds()/86400
    df['purchase_month']=df.order_purchase_timestamp.dt.to_period('M').astype(str)
    return df

def overview(db:Path):
    df=order_facts(db)
    delivered=df[df.order_status=='delivered'].copy()
    eligible=df[df.delivered_with_dates]
    return {'orders':len(df),'delivered':len(delivered),'merchandise_value':float(delivered.merchandise_value.sum()),
            'eligible_delivery':len(eligible),'late_rate':float(eligible.late_delivery.mean()) if len(eligible) else None,
            'reviewed':int(df.avg_review_score.notna().sum()), 'monthly':df.groupby('purchase_month',as_index=False).agg(orders=('order_id','nunique')),
            'states':eligible.groupby('customer_state',dropna=False).agg(eligible_orders=('order_id','size'),late_orders=('late_delivery','sum'),avg_delivery_days=('delivery_days','mean')).reset_index()}

def seller_ranking(db:Path,min_orders=20):
    # seller item join is many-to-many by order, so rank seller-order exposures, not unique marketplace orders.
    with sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True) as con:
        query="""WITH seller_order AS (
             SELECT seller_id,order_id,SUM(COALESCE(price,0)) item_value FROM order_items
             GROUP BY seller_id,order_id
            )
            SELECT i.seller_id,s.seller_state,COUNT(*) seller_orders,
                   SUM(CASE WHEN o.order_status='delivered' AND o.order_delivered_customer_date IS NOT NULL
                       AND o.order_estimated_delivery_date IS NOT NULL THEN 1 ELSE 0 END) eligible_orders,
                   SUM(CASE WHEN o.order_status='delivered' AND o.order_delivered_customer_date IS NOT NULL
                       AND o.order_estimated_delivery_date IS NOT NULL
                       AND o.order_delivered_customer_date>o.order_estimated_delivery_date THEN 1 ELSE 0 END) late_orders,
                   SUM(CASE WHEN o.order_status='delivered' THEN i.item_value ELSE 0 END) merchandise_value
            FROM seller_order i JOIN orders o ON i.order_id=o.order_id
            LEFT JOIN sellers s ON i.seller_id=s.seller_id
            GROUP BY i.seller_id,s.seller_state"""
        df=pd.read_sql_query(query,con)
    df=df[df.eligible_orders>=min_orders].copy()
    df['late_rate']=df.late_orders/df.eligible_orders
    return df.sort_values(['late_orders','late_rate'],ascending=False).reset_index(drop=True)

def review_relation(db:Path):
    df=order_facts(db)
    eligible=df[df.delivered_with_dates & df.avg_review_score.notna()].copy()
    if eligible.empty:return pd.DataFrame(columns=['late_delivery','orders','mean_review_score','low_rating_rate'])
    eligible['low_rating']=eligible.avg_review_score<=2
    return eligible.groupby('late_delivery').agg(orders=('order_id','nunique'),mean_review_score=('avg_review_score','mean'),low_rating_rate=('low_rating','mean')).reset_index()

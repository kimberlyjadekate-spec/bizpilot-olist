"""Optional, clearly synthetic auxiliary data; never claim observed business causes."""
from __future__ import annotations
import sqlite3
from pathlib import Path
import numpy as np
import pandas as pd

KEYS=['day','region','channel','category']

def ensure_demo_sources(db: str | Path) -> bool:
    """Build independent synthetic operations tables, idempotent, without changing core facts.

    Only for bundled synthetic demo. NEVER call on a user-uploaded database.
    """
    with sqlite3.connect(db) as conn:
        present={r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if {'marketing_daily','inventory_daily','refund_daily','promotion_daily','payment_daily'}.issubset(present):return False
        data=pd.read_sql_query('SELECT day,region,channel,category,visits,orders,revenue FROM daily_metrics',conn)
        rng=np.random.default_rng(7026)
        paid=data['channel'].eq('Paid')
        # Auxiliary metrics are synthetic, not a reconstruction of real exposures or conversions.
        impressions=np.where(paid,np.maximum(1,(data['visits'].to_numpy()*rng.uniform(6,9,len(data))).astype(int)),0)
        clicks=np.where(paid,np.maximum(1,(data['visits'].to_numpy()*rng.uniform(1.1,1.5,len(data))).astype(int)),0)
        spend=np.where(paid,np.round(clicks*rng.uniform(.42,.82,len(data)),2),0.)
        marketing=data[KEYS].copy();marketing['impressions']=impressions;marketing['clicks']=clicks;marketing['ad_spend']=spend
        recent=pd.to_datetime(data['day'])>=pd.Timestamp('2026-10-23')
        east_paid_elec=recent & data['region'].eq('East') & paid & data['category'].eq('Electronics')
        # Simulated external warning pattern, not proved to drive the core traffic incident.
        marketing.loc[east_paid_elec,'impressions']=(marketing.loc[east_paid_elec,'impressions']*.57).round().astype(int)
        marketing.to_sql('marketing_daily',conn,index=False,if_exists='replace')
        inventory=data[KEYS].copy()
        inventory['stockout_hours']=np.round(rng.uniform(0,2,len(data)),1)
        inventory['available_skus']=rng.integers(25,81,size=len(data))
        inventory['stockout_rate']=np.round(inventory['stockout_hours']/24,4)
        inventory.to_sql('inventory_daily',conn,index=False,if_exists='replace')
        refund=data[KEYS].copy();refund['refund_orders']=rng.binomial(data['orders'].clip(lower=0).astype(int).to_numpy(),.023)
        refund['refund_amount']=np.round(refund['refund_orders']*np.where(data['orders']>0,data['revenue']/data['orders'].clip(lower=1),0)*.8,2)
        refund.to_sql('refund_daily',conn,index=False,if_exists='replace')
        promotion=data[KEYS].copy()
        promotion['coupon_orders']=rng.binomial(data['orders'].clip(lower=0).astype(int).to_numpy(),.17)
        promotion['coupon_discount']=np.round(promotion['coupon_orders'] * rng.uniform(3,12,len(data)),2)
        # Independent simulated coincidence around the known AOV event; not its proven cause.
        home_window=recent & data['region'].eq('West') & data['channel'].eq('Organic') & data['category'].eq('Home')
        promotion.loc[home_window,'coupon_discount']=(promotion.loc[home_window,'coupon_discount']*1.65).round(2)
        promotion.to_sql('promotion_daily',conn,index=False,if_exists='replace')
        payment=data[KEYS].copy()
        payment['payment_attempts']=data['orders'].astype(int)+rng.binomial(data['orders'].clip(lower=0).astype(int).to_numpy(),.05)
        payment['payment_failures']=np.maximum(0,payment['payment_attempts']-data['orders'])
        payment.to_sql('payment_daily',conn,index=False,if_exists='replace')
    return True


def source_registry(db:str|Path)->dict:
    with sqlite3.connect(db) as con:
        tables={x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        return {t:(t in tables) for t in ['daily_metrics','marketing_daily','inventory_daily','refund_daily','promotion_daily','payment_daily']}


def analyze_extra_question(db:str|Path,q:str,days:int=7):
    """Aggregate from only allowlisted tables. Parameterized by fixed metric definitions."""
    lower=q.lower()
    selectors={
      'marketing_daily':{'words':('广告','投放','曝光','点击','营销','roas','ad_spend','花费'),
          'metrics':{'ad_spend':'广告花费','impressions':'广告曝光','clicks':'广告点击'}},
      'inventory_daily':{'words':('库存','缺货','sku','stock'),
          'metrics':{'stockout_hours':'缺货小时数'}},
      'refund_daily':{'words':('退款','退货','refund'),
          'metrics':{'refund_orders':'退款订单数','refund_amount':'退款金额'}},
      'promotion_daily':{'words':('优惠券','优惠','促销','折扣','coupon','discount'),
          'metrics':{'coupon_orders':'优惠订单数','coupon_discount':'优惠金额'}},
      'payment_daily':{'words':('支付失败','支付尝试','payment'),
          'metrics':{'payment_failures':'支付失败次数','payment_attempts':'支付尝试次数'}},
    }
    selected=next(((table,defn) for table,defn in selectors.items() if any(w in lower for w in defn['words'])),None)
    if not selected:return None
    table,defn=selected
    with sqlite3.connect(db) as con:
        has=con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone()
        if not has:return {'type':'unsupported','reason':f'当前数据源未包含 {table}，无法回答该问题；请连接相应数据表。'}
        end=con.execute('SELECT MAX(day) FROM daily_metrics').fetchone()[0]
        if not end:return {'type':'unsupported','reason':'数据源为空'}
        end_date=pd.Timestamp(end)
        current_start=(end_date-pd.Timedelta(days=days-1)).strftime('%Y-%m-%d')
        prior_start=(end_date-pd.Timedelta(days=days*2-1)).strftime('%Y-%m-%d')
        prior_end=(end_date-pd.Timedelta(days=days)).strftime('%Y-%m-%d')
        metric=next((m for m,label in defn['metrics'].items() if label.replace('广告','') in q or m in lower),None)
        if metric is None:
            metric='ad_spend' if table=='marketing_daily' else 'stockout_hours' if table=='inventory_daily' else 'coupon_discount' if table=='promotion_daily' else 'payment_failures' if table=='payment_daily' else 'refund_amount'
        sql=f'SELECT day, region, channel, category, {metric} AS value FROM {table} WHERE day BETWEEN ? AND ?'
        f=pd.read_sql_query(sql,con,params=(prior_start,end))
    current=f[(f.day>=current_start)&(f.day<=end)];previous=f[(f.day>=prior_start)&(f.day<=prior_end)]
    dims=['channel','region','category'];dim=next((d for d,words in {
        'channel':('渠道','paid','organic','referral'),'region':('地区','区域','east','west','north','south','东部','西部'),
        'category':('品类','类目','electronics','home','beauty')}.items() if any(w in lower for w in words)),'channel' if table=='marketing_daily' else 'category')
    grouped=current.groupby(dim)['value'].sum();prev_grouped=previous.groupby(dim)['value'].sum()
    comparison=[]
    for name in sorted(set(grouped.index)|set(prev_grouped.index)):
        now=float(grouped.get(name,0));prev=float(prev_grouped.get(name,0))
        comparison.append({'分组':name,'本期':round(now,2),'上期':round(prev,2),'变化金额/数量':round(now-prev,2),
                           '变化率%':round((now/prev-1)*100,2) if prev else None})
    return {'type':'auxiliary','table':table,'metric':metric,'metric_label':defn['metrics'][metric],
            'current':float(current.value.sum()),'previous':float(previous.value.sum()),
            'groups':comparison,'group_by':dim,'start':current_start,'end':end,
            'notice':'辅助表数据为可复现的合成示例，仅可用于模拟核查；和经营指标同时变化不构成因果证据。'}

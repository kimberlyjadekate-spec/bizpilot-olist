"""Query-backed, scoped business overview; no model-generated numeric claims."""
from __future__ import annotations
from dataclasses import dataclass
import pandas as pd
from .deep_analysis import shapley_revenue

DIMENSIONS=('region','channel','category')
METRICS=('revenue','orders','visits','conversion','aov')


def prepare_frame(frame:pd.DataFrame)->pd.DataFrame:
    required={'day','region','channel','category','revenue','orders','visits'}
    missing=required-set(frame.columns)
    if missing: raise ValueError(f'Missing columns: {sorted(missing)}')
    out=frame.copy()
    out['day']=pd.to_datetime(out['day'])
    return out


def period_window(frame:pd.DataFrame, length:int|None=7, compare:bool=True):
    """Windows anchored to dataset max date, not wall-clock time.

    Returns (current, previous, metadata). For all data, comparison is disabled.
    """
    f=prepare_frame(frame)
    max_date=f['day'].max()
    if pd.isna(max_date):
        return f, None, {'current_start':None,'current_end':None,'previous_start':None,'previous_end':None,'comparison_available':False,'notice':'数据为空'}
    min_date=f['day'].min()
    if length is None:
        current=f
        previous=None
        start=min_date
        comp=False
    else:
        start=max_date-pd.Timedelta(days=length-1)
        current=f[(f.day>=start)&(f.day<=max_date)]
        old_end=start-pd.Timedelta(days=1)
        old_start=old_end-pd.Timedelta(days=length-1)
        old=f[(f.day>=old_start)&(f.day<=old_end)]
        full_current=current['day'].nunique()==length
        full_previous=old['day'].nunique()==length
        comp=bool(compare and full_current and full_previous)
        previous=old if comp else None
    notice=None
    if length is None:
        notice='全部数据为单一观测窗口，不提供上一周期比较。'
    elif not comp:
        notice='上一等长周期或当前周期数据不足：已隐藏变化率与贡献拆解。' if compare else '已关闭上一周期对比。'
    meta={'current_start':start, 'current_end':max_date,
          'previous_start':(start-pd.Timedelta(days=length)) if (length and comp) else None,
          'previous_end':(start-pd.Timedelta(days=1)) if (length and comp) else None,
          'comparison_available':comp,'notice':notice}
    return current,previous,meta


def filter_frame(frame, region='全部',channel='全部',category='全部'):
    result=frame
    for column,value in (('region',region),('channel',channel),('category',category)):
        if value not in ('全部',None):result=result[result[column]==value]
    return result.copy()


def metrics(frame):
    visits=int(frame['visits'].sum()) if len(frame) else 0
    orders=int(frame['orders'].sum()) if len(frame) else 0
    rev=float(frame['revenue'].sum()) if len(frame) else 0.
    return {'revenue':rev,'orders':orders,'visits':visits,
            'conversion':100*orders/visits if visits else None,
            'aov':rev/orders if orders else None}


def metric_change(current,previous,key):
    if previous is None or current is None:return None
    if key=='conversion':return current-previous # percentage points
    if previous==0:return None
    return (current/previous-1)*100


def factors_from_metrics(m):
    return {'visits':float(m['visits']),
            'conversion':float(m['orders'])/m['visits'] if m['visits'] else 0.,
            'aov':float(m['revenue'])/m['orders'] if m['orders'] else 0.}


def drivers(current,previous):
    if previous is None or current is None:return None
    result=shapley_revenue(factors_from_metrics(previous),factors_from_metrics(current))
    result['aov']+=(current['revenue']-previous['revenue'])-sum(result.values())
    return result


def breakdown(current,previous,dimension):
    if dimension not in DIMENSIONS:raise ValueError('Invalid dimension')
    rows=[]
    keys=sorted(set(current[dimension])|set(previous[dimension]) if previous is not None else set(current[dimension]))
    for key in keys:
        c=metrics(current[current[dimension]==key])
        p=metrics(previous[previous[dimension]==key]) if previous is not None else None
        delta=c['revenue']-p['revenue'] if p else None
        rows.append({'group':key,'current_revenue':c['revenue'],'previous_revenue':p['revenue'] if p else None,
                     'delta':delta,'change_pct':metric_change(c['revenue'],p['revenue'],'revenue') if p else None,
                     'orders':c['orders'],'visits':c['visits']})
    return pd.DataFrame(rows)


def anomaly_candidates(current, previous, top_n=5):
    if previous is None or current.empty:return []
    rows=[]
    for keys,cgroup in current.groupby(list(DIMENSIONS),dropna=False):
        pgroup=previous
        for col,v in zip(DIMENSIONS,keys):pgroup=pgroup[pgroup[col]==v]
        c=metrics(cgroup);p=metrics(pgroup)
        delta=c['revenue']-p['revenue']
        if delta>=-0.000001:continue
        d=drivers(c,p)
        rows.append({'region':keys[0],'channel':keys[1],'category':keys[2],
                     'current':c,'previous':p,'delta':delta,'change_pct':metric_change(c['revenue'],p['revenue'],'revenue'),
                     'drivers':d,'primary':min(d,key=d.get)})
    return sorted(rows,key=lambda r:r['delta'])[:top_n]


def latest_daily_trend(frame, metric='revenue'):
    if frame.empty:return pd.DataFrame(columns=['day','value'])
    out=frame.groupby('day',as_index=False)[['revenue','orders','visits']].sum().sort_values('day')
    if metric=='conversion':out['value']=out.apply(lambda r:100*r['orders']/r['visits'] if r['visits'] else float('nan'),axis=1)
    elif metric=='aov':out['value']=out.apply(lambda r:r['revenue']/r['orders'] if r['orders'] else float('nan'),axis=1)
    else:out['value']=out[metric]
    return out[['day','value']]

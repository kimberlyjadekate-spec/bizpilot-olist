"""Reproducible synthetic business dataset with known injected incidents."""
from pathlib import Path
import sqlite3
import numpy as np
import pandas as pd

REGIONS = ('East', 'West', 'North', 'South')
CHANNELS = ('Organic', 'Paid', 'Referral')
CATEGORIES = ('Electronics', 'Home', 'Beauty')


def make_demo_data(path: str | Path, seed: int = 2026, incidents=None) -> Path:
    """Generate reproducible synthetic dataset.

    incidents: list of {'region','channel','category','mechanism','factor'}.
    None selects original two V0.1 demo incidents. [] means zero injections.
    Mechanisms: visits, conversion, aov. factor in (0,1].
    """
    if incidents is None:
        incidents = [
          {'region':'East','channel':'Paid','category':'Electronics','mechanism':'visits','factor':.48},
          {'region':'West','channel':'Organic','category':'Home','mechanism':'aov','factor':.64},
        ]
    for item in incidents:
        if item.get('region') not in REGIONS or item.get('channel') not in CHANNELS or item.get('category') not in CATEGORIES:
            raise ValueError('Invalid incident segment')
        if item.get('mechanism') not in ('visits','conversion','aov') or not 0 < float(item.get('factor',0)) <= 1:
            raise ValueError('Invalid mechanism or factor')
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    days = pd.date_range('2026-08-01', '2026-10-29', freq='D')
    rows = []
    for date in days:
        recent = date >= pd.Timestamp('2026-10-23')
        weekday_multiplier = 1.12 if date.dayofweek in (5, 6) else 1.0
        for region in REGIONS:
            for channel in CHANNELS:
                for category in CATEGORIES:
                    base_visits = {'East': 950, 'West': 760, 'North': 620, 'South': 690}[region]
                    base_visits *= {'Organic': 1.0, 'Paid': 0.85, 'Referral': 0.4}[channel]
                    base_visits *= {'Electronics': 1.0, 'Home': 0.85, 'Beauty': 0.65}[category]
                    visits = max(1, round(base_visits * weekday_multiplier * rng.uniform(.97, 1.03)))
                    conversion_rate = {'Organic': .05, 'Paid': .045, 'Referral': .06}[channel]
                    aov = {'Electronics': 145.0, 'Home': 85.0, 'Beauty': 45.0}[category]
                    if recent:
                        for incident in incidents:
                            if (region,channel,category) == (incident['region'], incident['channel'], incident['category']):
                                if incident['mechanism'] == 'visits':
                                    visits = max(1, round(visits * incident['factor']))
                                elif incident['mechanism'] == 'conversion':
                                    conversion_rate *= incident['factor']
                                elif incident['mechanism'] == 'aov':
                                    aov *= incident['factor']
                    orders = max(0, round(visits * conversion_rate * rng.uniform(.96, 1.04)))
                    revenue = round(orders * aov, 2)
                    rows.append((date.strftime('%Y-%m-%d'), region, channel, category, visits, orders, revenue))
    con = sqlite3.connect(path)
    with con:
        con.execute('DROP TABLE IF EXISTS daily_metrics')
        con.execute('''CREATE TABLE daily_metrics (
            day TEXT NOT NULL, region TEXT NOT NULL, channel TEXT NOT NULL,
            category TEXT NOT NULL, visits INTEGER NOT NULL, orders INTEGER NOT NULL,
            revenue REAL NOT NULL,
            PRIMARY KEY(day, region, channel, category)
        )''')
        con.executemany('INSERT INTO daily_metrics VALUES(?,?,?,?,?,?,?)', rows)
    con.close()
    return path

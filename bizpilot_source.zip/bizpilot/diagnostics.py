"""Evidence-led multi-incident diagnostic engine.

This is a deterministic, auditable *baseline*, not an LLM agent. All
recommendations are descriptive and never assert an unmeasured causal driver.
"""
from dataclasses import dataclass
from .tools import BusinessTools
from .data import REGIONS, CHANNELS, CATEGORIES

LEAF_KEYS = ('region', 'channel', 'category')
MECHANISM_LABEL = {'visits': '流量', 'conversion': '转化率', 'aov': '客单价'}


def safe_change(before, after):
    if before is None or after is None or before <= 0:
        return None
    return round((after / before - 1) * 100, 2)


def find_incidents(tools: BusinessTools, max_incidents=8, minimum_decline=18.0):
    """Enumerate comparable 3-D slices; rank non-overlapping leaf incidents.

    The mechanism is the most negative relative change among visits,
    conversion and AOV. Revenue change alone is *not* a causal explanation.
    """
    findings = []
    for region in REGIONS:
        for channel in CHANNELS:
            for category in CATEGORIES:
                filters = {'region':region, 'channel':channel, 'category':category}
                m = tools.segment_metrics(filters)
                prev, curr = m['revenue']['before_value'], m['revenue']['after_value']
                changes = {
                    'visits': m['visits']['change_pct'],
                    'conversion': safe_change(m['before_conversion'], m['after_conversion']),
                    'aov': safe_change(m['before_aov'], m['after_aov']),
                }
                valid = {k:v for k,v in changes.items() if v is not None}
                if not valid or prev <= 0:
                    continue
                cause = min(valid, key=valid.get)
                # Thresholds protect against declaring small sampling jitter an incident.
                if valid[cause] > -minimum_decline or m['revenue']['delta'] >= 0:
                    continue
                findings.append({
                    'filters':filters, 'mechanism':cause, 'mechanism_zh':MECHANISM_LABEL[cause],
                    'mechanism_change_pct':valid[cause],
                    'revenue_delta':round(curr-prev,2),
                    'revenue_change_pct':m['revenue']['change_pct'],
                    'visits_change_pct':changes['visits'],
                    'conversion_change_pct':changes['conversion'],
                    'aov_change_pct':changes['aov'],
                    'before_revenue':prev, 'after_revenue':curr,
                    'before_orders':m['orders']['before_value'],
                    'after_orders':m['orders']['after_value'],
                    'notes': '指标变化为观察事实，不足以证明外部业务根因。',
                })
    findings.sort(key=lambda x: (x['revenue_delta'], x['filters']['region'], x['filters']['channel'], x['filters']['category']))
    return findings[:max_incidents]


def diagnose_all(db_path, max_incidents=8):
    tools = BusinessTools(db_path)
    quality = tools.data_quality()
    overview = tools.metric_overview('revenue')
    segment = tools.segment_metrics()
    incidents = find_incidents(tools, max_incidents=max_incidents)
    largest = incidents[0] if incidents else None
    if quality['complete'] is False or quality['invalid_rows']:
        conclusion = '数据质量检查未通过，请优先检查数据完整性；本次诊断不应直接用于经营决策。'
    elif incidents:
        top = largest
        label = ' / '.join(top['filters'].values())
        conclusion = (f"本期收入 {overview['after_value']:,.0f}，环比 {overview['change_pct']}%。"
                      f"识别 {len(incidents)} 个达到阈值的业务细分组合。"
                      f"首要异常：{label}，收入变化 {top['revenue_delta']:,.0f}，"
                      f"其中{top['mechanism_zh']}下降 {abs(top['mechanism_change_pct']):.1f}%。"
                      '这是指标层面的主要变化机制，不等于已经证明渠道、产品或管理原因。')
    else:
        conclusion = ('未识别达到阈值的细分指标异常。'
                      '这不代表经营指标完全正常，可进一步分析趋势和外部业务事件。')
    return {
        'mode':'deterministic multi-incident baseline (no LLM)',
        'version':'0.2.0', 'summary':conclusion, 'quality':quality,
        'overview':overview, 'all_metrics':segment,
        'incidents':incidents, 'traces':tools.trace,
        'limitations':['固定相邻七日比较；没有季节性校正','观测数据只支持贡献分析，不支持因果归因',
                       '固定维度及阈值，仅用于演示与回归测试'],
    }

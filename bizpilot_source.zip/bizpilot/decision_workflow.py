"""Evidence-gated decision workflow for an operations analyst assistant.

The independent accounting layer checks ALL leaves once, while the local LLM
chooses which evidence gap to examine next; model conclusions are not trusted
for numeric facts. This is a *hybrid* agent, not a purely autonomous model.
"""
from __future__ import annotations
import json
import time
from .deep_analysis import investigation
from .tools import BusinessTools
from .local_agent import _request, _local_url, DEFAULT_URL, DEFAULT_MODEL, LocalAgentError

CHECKS = {
    'traffic': {'label': '核查流量与渠道投放', 'questions': ['核对渠道曝光、点击量、预算与投放状态', '检查埋点、归因和访问日志是否缺失'], 'owner': '增长运营 / 数据工程'},
    'conversion': {'label': '核查转化与用户漏斗', 'questions': ['核对商品库存、页面可用性及支付失败率', '分渠道检查商品详情→下单→支付漏斗'], 'owner': '产品运营 / 交易产品'},
    'pricing': {'label': '核查价格与客单价', 'questions': ['核对SKU结构、标价、折扣和优惠券变化', '检查退款口径和高客单订单跨期情况'], 'owner': '商品运营 / 财务BP'},
}
FACTOR_CHECK={'visits':'traffic','conversion':'conversion','aov':'pricing'}


def compact_evidence(deep):
    """Small factual payload; do not send thousands of raw rows to the model."""
    return {'net_delta':deep['net_delta'],'net_pct':round(deep['net_pct'],2),
            'data_valid':deep['data_quality']['complete'] and not deep['data_quality']['invalid_rows'] and deep['reconciles'],
            'candidates':[{'key':f"{x['region']}/{x['channel']}/{x['category']}",
               'revenue_delta':x['delta'],'driver':x['primary_driver'],
               'drivers':x['drivers'],'change_pct':x['metrics_change_pct']}
               for x in deep['candidates'][:4]]}


def required_checks(deep):
    """Deterministic evidence gates: each material candidate needs a mechanism check."""
    return [dict(segment=f"{x['region']}/{x['channel']}/{x['category']}",
                 kind=FACTOR_CHECK[x['primary_driver']],
                 filters={k:x[k] for k in ('region','channel','category')})
            for x in deep['candidates'][:2]]


def _action(raw, remaining):
    """Strictly parse selected known checks; reject invented tools and segments."""
    if isinstance(raw,str):
        raw=raw.strip()
        if raw.startswith('```'):
            raw=raw.partition('\n')[2].rsplit('```',1)[0]
        raw=json.loads(raw)
    if not isinstance(raw,dict): raise ValueError('响应必须是JSON对象')
    try: index=int(raw['candidate_index'])
    except (KeyError,TypeError,ValueError) as exc: raise ValueError('缺少合法candidate_index') from exc
    if index not in remaining: raise ValueError('必须选择尚未检查的重点异常')
    return index


def _choose_llm(model, base, question, evidence, remaining, examined, requester):
    prompt=("你是企业经营分析师，负责从候选异常中选择下一项最有价值的证据核查。"
      "你只能在remaining_indices里面选择一个，不要编造业务根因，不要输出其他文字。"
      '严格JSON格式：{"candidate_index":0,"reason":"..."}。'
      f'\n用户问题：{question[:450]}\n已证实的指标：{json.dumps(evidence,ensure_ascii=False)}'
      f'\n已检查：{json.dumps(examined,ensure_ascii=False)}\nremaining_indices={remaining}')
    response=requester(base,'/api/chat',payload={'model':model,'stream':False,'format':'json',
          'messages':[{'role':'user','content':prompt}],
          'options':{'temperature':0,'num_predict':110},'keep_alive':'5m'},timeout=120)
    message=response.get('message') or {}
    return _action(message.get('content',''),remaining), response


def _workflow_result(deep, checks, visited, decisions, timing, model, failed=False, errors=None, models=0, usage=None):
    quality=deep['data_quality']; full=bool(quality['complete'] and not quality['invalid_rows'] and deep['reconciles'])
    verified=len(visited)==len(checks) and full
    actions=[]
    for x in checks:
        meta=CHECKS[x['kind']]
        actions.append({'segment':x['segment'],'status':'指标已核验' if x['segment'] in visited else '待核验',
            'team':meta['owner'],'check':meta['label'],'questions':meta['questions'],
            'evidence_needed':'需要业务侧补充真实渠道/库存/价格/日志数据，当前模拟表无法确认外部原因'})
    return {'mode':'hybrid evidence-guided agent','model':model,'verified':verified,
            'independent_revenue_reconciles':deep['reconciles'],
            'quality_pass':full,'required':len(checks),'checked':len(visited),
            'decisions':decisions,'actions':actions,'errors':errors or [],
            'model_calls':models,'usage':usage or {'prompt_eval_count':0,'eval_count':0},
            'elapsed_seconds':round(time.monotonic()-timing,2),'failed':failed,
            'summary':('已完成重点异常的指标核验；尚不能确认外部业务原因。' if verified else
                       '重点异常尚未全部完成指标核验；不能输出全面诊断。')}


def investigate_hybrid(db_path, question='为什么收入下降？', model=DEFAULT_MODEL, base=DEFAULT_URL,
                       requester=_request, deep=None, max_llm_calls=2):
    """Evidence-first local agent. Always checks the top material anomalies.

    An LLM chooses the order and explains why, but an evidence gate prevents
    stopping after a shallow channel/category only query. One lightweight LLM
    call per candidate, with deterministic fallback if the model is malformed.
    """
    _local_url(base)
    if not isinstance(question,str) or len(question)>2000: raise ValueError('问题过长')
    if not 0 <= max_llm_calls <= 6: raise ValueError('max_llm_calls must be between 0 and 6')
    t0=time.monotonic()
    deep=deep if deep is not None else investigation(db_path)
    checks=required_checks(deep)
    facts=compact_evidence(deep)
    tools=BusinessTools(db_path)
    visited={}; decisions=[]; errors=[]; models=0
    usage={'prompt_eval_count':0,'eval_count':0}
    quality=tools.data_quality()
    if not quality['complete'] or quality['invalid_rows'] or not deep['reconciles']:
        errors.append('数据质量或收入核对失败：停止诊断，禁止生成经营建议。')
        return _workflow_result(deep,checks,visited,decisions,t0,model,True,errors,models,usage)
    remaining=list(range(len(checks)))
    while remaining:
        idx=remaining[0]; selection='规则兜底'
        if models<max_llm_calls:
            try:
                idx,response=_choose_llm(model,base,question,facts,remaining,decisions,requester)
                selection='模型选择'
                models+=1
                for key in usage: usage[key]+=response.get(key,0) or 0
            except (ValueError,KeyError,TypeError,LocalAgentError,TimeoutError,OSError) as exc:
                errors.append(f'本地模型选择失败，已使用可核验规则兜底：{type(exc).__name__}: {str(exc)[:100]}')
                models+=1
        current=checks[idx]; remaining.remove(idx)
        result=tools.segment_metrics(current['filters'])
        visited[current['segment']]={'result':result,'kind':current['kind']}
        decisions.append({'step':len(decisions)+1,'selected_by':selection,'segment':current['segment'],
            'reason':f"该组合需要核查{CHECKS[current['kind']]['label']}，先确认三项经营指标再要求业务侧补充原因证据。",
            'evidence':{'revenue_delta':round(result['revenue']['delta'],2),
                'visits_delta':result['visits']['delta'],'orders_delta':result['orders']['delta'],
                'before_conversion':result['before_conversion'],'after_conversion':result['after_conversion'],
                'before_aov':result['before_aov'],'after_aov':result['after_aov']},
            'remaining_gaps':len(remaining)})
    return _workflow_result(deep,checks,visited,decisions,t0,model,False,errors,models,usage)

"""Opt-in local CSV business facts import. Only documented schema; no arbitrary SQL."""
from pathlib import Path
import io
import sqlite3
import pandas as pd

COLUMNS=['day','region','channel','category','visits','orders','revenue']

def import_daily_csv(content:bytes,target:Path):
    if len(content)>20*1024*1024:raise ValueError('文件超过20MB上限')
    try:frame=pd.read_csv(io.BytesIO(content),encoding='utf-8-sig')
    except Exception as err:raise ValueError('CSV格式无效或无法按UTF-8读取') from err
    if set(COLUMNS)-set(frame.columns):raise ValueError('缺少字段：'+', '.join(sorted(set(COLUMNS)-set(frame.columns))))
    data=frame[COLUMNS].copy()
    if data.empty or len(data)>150000:raise ValueError('数据量必须在1至150000行之间')
    if data.isna().any().any():raise ValueError('不允许关键字段存在空值')
    dates=pd.to_datetime(data['day'],errors='coerce',format='%Y-%m-%d')
    if dates.isna().any():raise ValueError('日期必须使用YYYY-MM-DD格式')
    data['day']=dates.dt.strftime('%Y-%m-%d')
    for dim in ['region','channel','category']:
        data[dim]=data[dim].astype(str).str.strip()
        if (data[dim]=='').any() or (data[dim].str.len()>80).any():raise ValueError(dim+'存在空白或过长分类')
    for metric in ['visits','orders','revenue']:
        data[metric]=pd.to_numeric(data[metric],errors='coerce')
        if data[metric].isna().any() or (data[metric]<0).any():raise ValueError(metric+'必须为非负数')
    for count in ['visits','orders']:
        if (data[count]%1!=0).any():raise ValueError(count+'必须为整数')
        data[count]=data[count].astype('int64')
    if (data['orders']>data['visits']).any():raise ValueError('订单数不能超过访问量（当前指标定义限制）')
    if data.duplicated(['day','region','channel','category']).any():raise ValueError('日期、地区、渠道、品类的组合必须唯一')
    target.parent.mkdir(parents=True,exist_ok=True)
    tmp=target.with_suffix('.tmp.db')
    try:
        with sqlite3.connect(tmp) as con:
            data.to_sql('daily_metrics',con,index=False,if_exists='replace')
            con.execute('CREATE UNIQUE INDEX daily_key ON daily_metrics(day,region,channel,category)')
        tmp.replace(target)
    finally:
        if tmp.exists():tmp.unlink()
    return {'rows':len(data),'days':data.day.nunique(),'from':data.day.min(),'to':data.day.max()}

AUX_SCHEMAS={
 'marketing_daily':('impressions','clicks','ad_spend'),
 'inventory_daily':('stockout_hours','available_skus'),
 'refund_daily':('refund_orders','refund_amount'),
 'promotion_daily':('coupon_orders','coupon_discount'),
 'payment_daily':('payment_attempts','payment_failures'),
}

def import_auxiliary_csv(content:bytes, target:Path,table:str)->dict:
    """Attach exactly one audited auxiliary CSV to an already-imported business DB.

    Must share one row per date/region/channel/category with daily_metrics;
    unmatched extra dimensions rejected; missing facts stay missing.
    """
    if table not in AUX_SCHEMAS:raise ValueError('未支持的数据源')
    if len(content)>20*1024*1024:raise ValueError('文件超过20MB')
    try: f=pd.read_csv(io.BytesIO(content),encoding='utf-8-sig')
    except Exception as e:raise ValueError('无法读取UTF-8 CSV') from e
    keys=['day','region','channel','category'];columns=keys+list(AUX_SCHEMAS[table])
    if set(columns)-set(f):raise ValueError('缺少字段：'+','.join(sorted(set(columns)-set(f))))
    f=f[columns].copy()
    if f.empty or len(f)>150000 or f.isna().any().any():raise ValueError('CSV为空、超出行数或含空值')
    parsed=pd.to_datetime(f.day,format='%Y-%m-%d',errors='coerce')
    if parsed.isna().any():raise ValueError('日期必须为YYYY-MM-DD')
    f['day']=parsed.dt.strftime('%Y-%m-%d')
    for key in keys[1:]:
        f[key]=f[key].astype(str).str.strip()
        if (f[key]=='').any() or (f[key].str.len()>80).any():raise ValueError('分类值不合法')
    for col in AUX_SCHEMAS[table]:
        f[col]=pd.to_numeric(f[col],errors='coerce')
        if f[col].isna().any() or not f[col].map(lambda v:bool(__import__('math').isfinite(v))).all() or (f[col]<0).any():
            raise ValueError(col+'必须是有限的非负数')
    if f.duplicated(keys).any():raise ValueError('同一日期与分组不能重复')
    target=Path(target)
    if not target.exists():raise ValueError('先导入经营主表')
    with sqlite3.connect(target) as conn:
        main={tuple(x) for x in conn.execute('SELECT day,region,channel,category FROM daily_metrics')}
        extra=set(map(tuple,f[keys].itertuples(index=False,name=None)))
        if extra-main:raise ValueError('辅助数据有主表不存在的日期或分组')
        f.to_sql(table,conn,index=False,if_exists='replace')
        conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_'+table+'_key ON '+table+'(day,region,channel,category)')
    return {'table':table,'rows':len(f),'matched_keys':len(extra),'source':'USER_CSV'}
